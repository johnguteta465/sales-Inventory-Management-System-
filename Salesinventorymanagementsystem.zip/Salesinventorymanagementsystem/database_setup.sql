-- SQL Server Database Script for Inventory Pro
CREATE DATABASE InventoryManagementSystemDB;
GO

USE InventoryManagementSystemDB;
GO

-- 1. Users Table (System Access)
CREATE TABLE Users (
    id INT PRIMARY KEY IDENTITY(1,1),
    login_user NVARCHAR(50) NOT NULL UNIQUE,
    password_user NVARCHAR(255) NOT NULL, -- Store hashed passwords
    permission NVARCHAR(20) NOT NULL -- Admin, Cashier, Manager, Customer
);

-- 2. Customers Table (Sales tracking)
CREATE TABLE Customers (
    id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20),
    email NVARCHAR(100),
    address NVARCHAR(MAX)
);

-- 3. Inventory Table
CREATE TABLE Inventory (
    id INT PRIMARY KEY IDENTITY(1,1),
    type_of NVARCHAR(100) NOT NULL, -- Product Name
    count_of INT DEFAULT 0, -- Stock Quantity
    supplier NVARCHAR(100),
    price DECIMAL(18, 2) NOT NULL, -- Selling Price
    barcode NVARCHAR(50) UNIQUE,
    buying_price DECIMAL(18, 2), -- Optional but recommended
    description NVARCHAR(MAX)
);

-- 4. Sales Table
CREATE TABLE Sales (
    id INT PRIMARY KEY IDENTITY(1,1),
    product_id INT FOREIGN KEY REFERENCES Inventory(id),
    customer_id INT FOREIGN KEY REFERENCES Customers(id), -- Linked to Customers
    quantity INT NOT NULL,
    total_price DECIMAL(18, 2) NOT NULL,
    payment_status NVARCHAR(20) DEFAULT 'Paid', -- Paid, Pending
    sale_date DATETIME DEFAULT GETDATE()
);

-- Insert Sample Data
INSERT INTO Users (login_user, password_user, permission) VALUES ('admin', 'admin123', 'Admin');
INSERT INTO Customers (name, phone, email) VALUES ('Guest Customer', '0000000000', 'guest@example.com');
INSERT INTO Inventory (type_of, count_of, supplier, price, barcode) VALUES ('Wireless Headphones', 50, 'Sony', 59.99, '123456789');
