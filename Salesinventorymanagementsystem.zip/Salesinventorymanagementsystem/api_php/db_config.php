<?xml version="1.0" encoding="utf-8"?>
<?php
// db_config.php - Database connection using PDO and SQLSRV driver
$serverName = "YOUR_SERVER_NAME"; // e.g., localhost or IP address
$connectionOptions = array(
    "Database" => "InventoryManagementSystemDB",
    "Uid" => "YOUR_USERNAME",
    "PWD" => "YOUR_PASSWORD"
);

try {
    $conn = new PDO("sqlsrv:server=$serverName;Database=InventoryManagementSystemDB", "YOUR_USERNAME", "YOUR_PASSWORD");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die(json_encode(array("error" => "Connection failed: " . $e->getMessage())));
}
?>
