<?php
require_once 'db_config.php';

try {
    $stmt = $conn->query("SELECT * FROM Inventory");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($products);
} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
