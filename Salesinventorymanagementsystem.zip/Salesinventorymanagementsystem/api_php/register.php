<?php
require_once 'db_config.php';

$login_user = $_POST['login_user'] ?? '';
$password_user = $_POST['password_user'] ?? '';
$permission = $_POST['permission'] ?? 'Cashier';

if (empty($login_user) || empty($password_user)) {
    echo json_encode(["error" => "All fields are required"]);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO Users (login_user, password_user, permission) VALUES (?, ?, ?)");
    $stmt->execute([$login_user, $password_user, $permission]);
    echo json_encode(["message" => "User registered successfully"]);
} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
