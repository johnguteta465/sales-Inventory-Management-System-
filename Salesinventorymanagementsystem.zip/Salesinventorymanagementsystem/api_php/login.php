<?php
require_once 'db_config.php';

$login_user = $_POST['login_user'] ?? '';
$password_user = $_POST['password_user'] ?? '';

if (empty($login_user) || empty($password_user)) {
    echo json_encode(["error" => "Username and password are required"]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT id, login_user, permission FROM Users WHERE login_user = ? AND password_user = ?");
    $stmt->execute([$login_user, $password_user]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        echo json_encode($user);
    } else {
        echo json_encode(["error" => "Invalid credentials"]);
    }
} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
