package com.example.salesinventorymanagementsystem.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;
import android.widget.Toast;

import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PdfHelper {

    public static void generateReceipt(Context context, Sale sale, List<SaleDetail> details, Map<String, String> settings) {
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(300, 800, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setTextSize(10f);

        int x = 10, y = 25;
        
        // Header - Business Info
        paint.setTextSize(14f);
        paint.setFakeBoldText(true);
        String bizName = settings.getOrDefault("business_name", "My Business");
        canvas.drawText(bizName, x + (280 - paint.measureText(bizName)) / 2, y, paint);
        
        paint.setTextSize(9f);
        paint.setFakeBoldText(false);
        y += 15;
        String bizAddr = settings.getOrDefault("business_address", "");
        canvas.drawText(bizAddr, x + (280 - paint.measureText(bizAddr)) / 2, y, paint);
        y += 12;
        String bizPhone = "Tel: " + settings.getOrDefault("business_phone", "");
        canvas.drawText(bizPhone, x + (280 - paint.measureText(bizPhone)) / 2, y, paint);
        
        y += 20;
        paint.setTextSize(12f);
        paint.setFakeBoldText(true);
        canvas.drawText("SALES RECEIPT", x + (280 - paint.measureText("SALES RECEIPT")) / 2, y, paint);
        
        y += 20;
        paint.setTextSize(9f);
        paint.setFakeBoldText(false);
        canvas.drawText("Sale ID: " + sale.getId(), x, y, paint);
        y += 12;
        String dateFormat = settings.getOrDefault("date_format", "yyyy-MM-dd");
        String timeFormat = settings.getOrDefault("time_format", "HH:mm");
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat + " " + timeFormat, Locale.getDefault());
        canvas.drawText("Date: " + sdf.format(new Date(sale.getTimestamp())), x, y, paint);
        y += 20;

        // Table Header
        paint.setFakeBoldText(true);
        canvas.drawText("Item", x, y, paint);
        canvas.drawText("Qty", x + 150, y, paint);
        canvas.drawText("Price", x + 190, y, paint);
        canvas.drawText("Total", x + 240, y, paint);
        y += 5;
        canvas.drawLine(x, y, 290, y, paint);
        y += 15;

        // Items
        paint.setFakeBoldText(false);
        String currency = settings.getOrDefault("currency_code", "$");
        for (SaleDetail detail : details) {
            canvas.drawText("Product #" + detail.getProductId(), x, y, paint);
            canvas.drawText(String.valueOf(detail.getQuantity()), x + 150, y, paint);
            canvas.drawText(String.format("%s%.2f", currency, detail.getUnitPrice()), x + 190, y, paint);
            canvas.drawText(String.format("%s%.2f", currency, detail.getSubtotal()), x + 240, y, paint);
            y += 15;
            
            if (y > 750) break; // Simple overflow check
        }

        y += 10;
        canvas.drawLine(x, y, 290, y, paint);
        y += 20;
        
        // Summary
        paint.setFakeBoldText(true);
        double subtotal = sale.getTotalAmount() - sale.getTax();
        canvas.drawText("SUBTOTAL:", x + 140, y, paint);
        canvas.drawText(String.format("%s%.2f", currency, subtotal), x + 240, y, paint);
        
        y += 15;
        canvas.drawText("TAX:", x + 140, y, paint);
        canvas.drawText(String.format("%s%.2f", currency, sale.getTax()), x + 240, y, paint);
        
        y += 20;
        paint.setTextSize(11f);
        canvas.drawText("GRAND TOTAL:", x + 120, y, paint);
        canvas.drawText(String.format("%s%.2f", currency, sale.getTotalAmount()), x + 240, y, paint);

        y += 30;
        paint.setTextSize(10f);
        paint.setFakeBoldText(false);
        String footer = settings.getOrDefault("receipt_message", "Thank you!");
        canvas.drawText(footer, x + (280 - paint.measureText(footer)) / 2, y, paint);

        document.finishPage(page);

        String fileName = "Receipt_" + sale.getId() + "_" + System.currentTimeMillis() + ".pdf";
        File file = new File(context.getExternalFilesDir(null), fileName);

        try {
            document.writeTo(new FileOutputStream(file));
            Toast.makeText(context, "Receipt saved: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(context, "Error generating PDF", Toast.LENGTH_SHORT).show();
        }

        document.close();
    }
}
