package com.example.salesinventorymanagementsystem.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.SaleDetail;

import java.util.ArrayList;
import java.util.List;

public class CartViewModel extends ViewModel {
    private final MutableLiveData<List<SaleDetail>> cartItems = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<Double> totalAmount = new MutableLiveData<>(0.0);

    public LiveData<List<SaleDetail>> getCartItems() {
        return cartItems;
    }

    public LiveData<Double> getTotalAmount() {
        return totalAmount;
    }

    public void addToCart(Product product) {
        List<SaleDetail> currentItems = new ArrayList<>(cartItems.getValue());
        boolean found = false;
        for (SaleDetail item : currentItems) {
            if (item.getProductId() == product.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                item.setSubtotal(item.getQuantity() * item.getUnitPrice());
                found = true;
                break;
            }
        }
        if (!found) {
            currentItems.add(new SaleDetail(0, product.getId(), 1, product.getPrice(), product.getPrice()));
        }
        cartItems.setValue(currentItems);
        calculateTotal();
    }

    public void updateQuantity(int position, int newQuantity) {
        List<SaleDetail> currentItems = new ArrayList<>(cartItems.getValue());
        if (position >= 0 && position < currentItems.size()) {
            if (newQuantity <= 0) {
                currentItems.remove(position);
            } else {
                SaleDetail item = currentItems.get(position);
                item.setQuantity(newQuantity);
                item.setSubtotal(newQuantity * item.getUnitPrice());
            }
            cartItems.setValue(currentItems);
            calculateTotal();
        }
    }

    public void removeItem(int position) {
        List<SaleDetail> currentItems = new ArrayList<>(cartItems.getValue());
        if (position >= 0 && position < currentItems.size()) {
            currentItems.remove(position);
            cartItems.setValue(currentItems);
            calculateTotal();
        }
    }

    public void clearCart() {
        cartItems.setValue(new ArrayList<>());
        totalAmount.setValue(0.0);
    }

    private void calculateTotal() {
        double total = 0;
        if (cartItems.getValue() != null) {
            for (SaleDetail item : cartItems.getValue()) {
                total += item.getSubtotal();
            }
        }
        totalAmount.setValue(total);
    }
}
