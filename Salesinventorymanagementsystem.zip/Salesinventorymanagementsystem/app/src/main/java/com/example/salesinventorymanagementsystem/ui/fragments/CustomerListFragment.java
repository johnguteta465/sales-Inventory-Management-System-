package com.example.salesinventorymanagementsystem.ui.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Customer;
import com.example.salesinventorymanagementsystem.ui.adapters.CustomerAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CustomerViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

public class CustomerListFragment extends Fragment implements CustomerAdapter.OnCustomerClickListener {

    private CustomerViewModel customerViewModel;
    private CustomerAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.rvCustomers);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CustomerAdapter(this);
        recyclerView.setAdapter(adapter);

        customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
        customerViewModel.getAllCustomers().observe(getViewLifecycleOwner(), customers -> {
            adapter.submitList(customers);
        });

        FloatingActionButton fab = view.findViewById(R.id.fabAddCustomer);
        fab.setOnClickListener(v -> showCustomerDialog(null));

        return view;
    }

    private void showCustomerDialog(Customer customer) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_customer, null);
        builder.setView(dialogView);

        TextInputEditText etName = dialogView.findViewById(R.id.etCustomerName);
        TextInputEditText etPhone = dialogView.findViewById(R.id.etCustomerPhone);
        TextInputEditText etEmail = dialogView.findViewById(R.id.etCustomerEmail);
        TextInputEditText etAddress = dialogView.findViewById(R.id.etCustomerAddress);

        if (customer != null) {
            builder.setTitle("Edit Customer");
            etName.setText(customer.getName());
            etPhone.setText(customer.getPhone());
            etEmail.setText(customer.getEmail());
            etAddress.setText(customer.getAddress());
        } else {
            builder.setTitle("Add Customer");
        }

        builder.setPositiveButton("Save", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String address = etAddress.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(getContext(), "Name is required", Toast.LENGTH_SHORT).show();
                return;
            }

            if (customer == null) {
                customerViewModel.insert(new Customer(name, phone, email, address));
            } else {
                customer.setName(name);
                customer.setPhone(phone);
                customer.setEmail(email);
                customer.setAddress(address);
                customerViewModel.update(customer);
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public void onEditClick(Customer customer) {
        showCustomerDialog(customer);
    }

    @Override
    public void onDeleteClick(Customer customer) {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete Customer")
                .setMessage("Are you sure?")
                .setPositiveButton("Yes", (dialog, which) -> customerViewModel.delete(customer))
                .setNegativeButton("No", null)
                .show();
    }
}
