package com.example.salesinventorymanagementsystem.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TopSellingAdapter extends RecyclerView.Adapter<TopSellingAdapter.ViewHolder> {

    private List<Product> topProducts = new ArrayList<>();

    public void setProducts(List<Product> products) {
        this.topProducts = products;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_top_selling_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = topProducts.get(position);
        holder.tvRank.setText(String.format(Locale.getDefault(), "%d.", position + 1));
        holder.tvName.setText(product.getName());
        // Mocking sold quantity and revenue for display based on image
        holder.tvSoldQty.setText("45 Sold"); 
        holder.tvRevenue.setText(String.format(Locale.getDefault(), "$%.2f", product.getPrice() * 45));
    }

    @Override
    public int getItemCount() {
        return Math.min(topProducts.size(), 5);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvRank, tvName, tvSoldQty, tvRevenue;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRank = itemView.findViewById(R.id.tvTopRank);
            tvName = itemView.findViewById(R.id.tvTopProductName);
            tvSoldQty = itemView.findViewById(R.id.tvTopSoldQty);
            tvRevenue = itemView.findViewById(R.id.tvTopRevenue);
        }
    }
}
