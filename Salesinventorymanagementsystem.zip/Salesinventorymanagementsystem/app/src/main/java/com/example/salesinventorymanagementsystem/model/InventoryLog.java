package com.example.salesinventorymanagementsystem.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory_logs",
        foreignKeys = @ForeignKey(entity = Product.class,
                parentColumns = "id",
                childColumns = "productId",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("productId")})
public class InventoryLog {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private int productId;
    private int changeAmount; // Positive for addition, negative for reduction
    private String reason; // e.g., "Restock", "Sale", "Damage"
    private long timestamp;

    public InventoryLog(int productId, int changeAmount, String reason, long timestamp) {
        this.productId = productId;
        this.changeAmount = changeAmount;
        this.reason = reason;
        this.timestamp = timestamp;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    public int getChangeAmount() { return changeAmount; }
    public void setChangeAmount(int changeAmount) { this.changeAmount = changeAmount; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
