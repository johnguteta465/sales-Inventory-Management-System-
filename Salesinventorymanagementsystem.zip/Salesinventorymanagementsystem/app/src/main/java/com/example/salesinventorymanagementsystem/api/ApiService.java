package com.example.salesinventorymanagementsystem.api;

import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    Call<User> login(
            @Field("login_user") String username,
            @Field("password_user") String password
    );

    @FormUrlEncoded
    @POST("register.php")
    Call<Void> register(
            @Field("login_user") String username,
            @Field("password_user") String password,
            @Field("permission") String role,
            @Field("full_name") String fullName
    );

    @GET("getProducts.php")
    Call<List<Product>> getProducts();

    @FormUrlEncoded
    @POST("addProduct.php")
    Call<Void> addProduct(
            @Field("type_of") String name,
            @Field("count_of") int stock,
            @Field("price") double price,
            @Field("barcode") String barcode,
            @Field("supplier") String supplier
    );
}
