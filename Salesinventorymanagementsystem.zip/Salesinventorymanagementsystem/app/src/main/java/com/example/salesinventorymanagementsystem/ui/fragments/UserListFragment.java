package com.example.salesinventorymanagementsystem.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.User;
import com.example.salesinventorymanagementsystem.viewmodel.UserViewModel;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class UserListFragment extends Fragment {

    private UserViewModel userViewModel;
    private RecyclerView rvUsers;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_list, container, false);

        rvUsers = view.findViewById(R.id.rvUsers);
        MaterialButton btnAddStaff = view.findViewById(R.id.btnAddStaff);

        rvUsers.setLayoutManager(new LinearLayoutManager(getContext()));
        
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        
        // Observe users and update list (simplified observation here)
        userViewModel.getAllUsers().observe(getViewLifecycleOwner(), users -> {
            // Update UI with user list
        });

        btnAddStaff.setOnClickListener(v -> showAddStaffDialog());

        return view;
    }

    private void showAddStaffDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_staff, null);
        EditText etName = dialogView.findViewById(R.id.etStaffName);
        EditText etEmail = dialogView.findViewById(R.id.etStaffEmail);
        EditText etPassword = dialogView.findViewById(R.id.etStaffPassword);
        RadioGroup rgRole = dialogView.findViewById(R.id.rgStaffRole);

        new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .setPositiveButton("Create Account", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String email = etEmail.getText().toString().trim();
                    String password = etPassword.getText().toString().trim();
                    String role = rgRole.getCheckedRadioButtonId() == R.id.rbCashier ? "Cashier" : "Inventory Manager";

                    if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                        Toast.makeText(getContext(), "All fields required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // SECURITY: Backend-style validation in ViewModel/Repository would happen here
                    new Thread(() -> {
                        User staff = new User(name, email, password, "", role);
                        userViewModel.insert(staff);
                        getActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Staff account created: " + role, Toast.LENGTH_SHORT).show());
                    }).start();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
