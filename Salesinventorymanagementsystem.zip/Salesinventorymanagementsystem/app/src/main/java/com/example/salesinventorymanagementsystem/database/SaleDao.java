package com.example.salesinventorymanagementsystem.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;

import java.util.List;

@Dao
public interface SaleDao {
    @Insert
    long insert(Sale sale);

    @Insert
    void insertDetails(List<SaleDetail> details);

    @Update
    void update(Sale sale);

    @Query("SELECT * FROM sales WHERE customer_id = :customerId ORDER BY timestamp DESC")
    LiveData<List<Sale>> getSalesByCustomer(int customerId);

    @Query("UPDATE sales SET order_status = :status WHERE id = :saleId")
    void updateStatus(int saleId, String status);

    @Query("SELECT * FROM sales ORDER BY timestamp DESC")
    LiveData<List<Sale>> getAllSales();

    @Query("SELECT * FROM sale_details WHERE sale_id = :saleId")
    LiveData<List<SaleDetail>> getDetailsForSale(int saleId);

    @Query("SELECT * FROM sale_details WHERE sale_id = :saleId")
    List<SaleDetail> getDetailsForSaleSync(int saleId);

    @Query("SELECT SUM(total_amount) FROM sales WHERE timestamp >= :startDate AND timestamp <= :endDate")
    LiveData<Double> getTotalRevenue(long startDate, long endDate);

    @Query("SELECT SUM(sd.quantity) FROM sale_details sd JOIN sales s ON sd.sale_id = s.id WHERE s.timestamp >= :startDate AND s.user_id = :userId")
    int getItemsSoldToday(long startDate, int userId);
    
    @Query("SELECT COUNT(*) FROM sales WHERE timestamp >= :startDate AND user_id = :userId")
    int getTransactionCountToday(long startDate, int userId);

    @Query("SELECT SUM(total_amount) FROM sales WHERE timestamp >= :startDate AND user_id = :userId")
    double getRevenueToday(long startDate, int userId);
}
