package com.example.salesinventorymanagementsystem.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Setting;
import com.example.salesinventorymanagementsystem.viewmodel.SettingViewModel;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsFragment extends Fragment {

    private SettingViewModel settingViewModel;
    private TextInputEditText etBusinessName, etBusinessPhone, etBusinessAddress;
    private TextInputEditText etCurrencyCode, etTaxRate, etLowStockLimit, etReceiptMessage;
    private SwitchMaterial swEnableTax, swLowStockAlerts, swEnableDiscounts, swPriceEditing;
    private Spinner spDateFormat, spTheme;
    private Button btnSave, btnBackup, btnRestore;

    private Map<String, String> currentSettings = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        initViews(view);
        setupSpinners();

        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);
        settingViewModel.getAllSettings().observe(getViewLifecycleOwner(), settings -> {
            if (settings != null) {
                for (Setting s : settings) {
                    currentSettings.put(s.getKey(), s.getValue());
                }
                populateViews();
            }
        });

        btnSave.setOnClickListener(v -> saveSettings());
        btnBackup.setOnClickListener(v -> Toast.makeText(getContext(), "Backup functionality coming soon", Toast.LENGTH_SHORT).show());
        btnRestore.setOnClickListener(v -> Toast.makeText(getContext(), "Restore functionality coming soon", Toast.LENGTH_SHORT).show());

        return view;
    }

    private void initViews(View view) {
        etBusinessName = view.findViewById(R.id.etBusinessName);
        etBusinessPhone = view.findViewById(R.id.etBusinessPhone);
        etBusinessAddress = view.findViewById(R.id.etBusinessAddress);
        etCurrencyCode = view.findViewById(R.id.etCurrencyCode);
        etTaxRate = view.findViewById(R.id.etTaxRate);
        etLowStockLimit = view.findViewById(R.id.etLowStockLimit);
        etReceiptMessage = view.findViewById(R.id.etReceiptMessage);
        swEnableTax = view.findViewById(R.id.swEnableTax);
        swLowStockAlerts = view.findViewById(R.id.swLowStockAlerts);
        swEnableDiscounts = view.findViewById(R.id.swEnableDiscounts);
        swPriceEditing = view.findViewById(R.id.swPriceEditing);
        spDateFormat = view.findViewById(R.id.spDateFormat);
        spTheme = view.findViewById(R.id.spTheme);
        btnSave = view.findViewById(R.id.btnSaveSettings);
        btnBackup = view.findViewById(R.id.btnBackup);
        btnRestore = view.findViewById(R.id.btnRestore);
    }

    private void setupSpinners() {
        String[] dateFormats = {"MMM dd, yyyy", "dd/MM/yyyy", "yyyy-MM-dd", "MM-dd-yyyy"};
        ArrayAdapter<String> dateAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, dateFormats);
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDateFormat.setAdapter(dateAdapter);

        String[] themes = {"Light", "Dark", "System Default"};
        ArrayAdapter<String> themeAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, themes);
        themeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTheme.setAdapter(themeAdapter);
    }

    private void populateViews() {
        etBusinessName.setText(currentSettings.getOrDefault("business_name", ""));
        etBusinessPhone.setText(currentSettings.getOrDefault("business_phone", ""));
        etBusinessAddress.setText(currentSettings.getOrDefault("business_address", ""));
        etCurrencyCode.setText(currentSettings.getOrDefault("currency_code", "ETB"));
        etTaxRate.setText(currentSettings.getOrDefault("tax_rate", "0"));
        etLowStockLimit.setText(currentSettings.getOrDefault("low_stock_limit", "10"));
        etReceiptMessage.setText(currentSettings.getOrDefault("receipt_message", ""));

        swEnableTax.setChecked(Boolean.parseBoolean(currentSettings.getOrDefault("tax_enabled", "false")));
        swLowStockAlerts.setChecked(Boolean.parseBoolean(currentSettings.getOrDefault("notifications_low_stock", "true")));
        swEnableDiscounts.setChecked(Boolean.parseBoolean(currentSettings.getOrDefault("sales_discounts_enabled", "true")));
        swPriceEditing.setChecked(Boolean.parseBoolean(currentSettings.getOrDefault("sales_price_editing", "false")));

        setSpinnerValue(spDateFormat, currentSettings.getOrDefault("date_format", "MMM dd, yyyy"));
        setSpinnerValue(spTheme, currentSettings.getOrDefault("appearance_theme", "Light"));
    }

    private void setSpinnerValue(Spinner spinner, String value) {
        ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).toString().equals(value)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void saveSettings() {
        List<Setting> settingsToUpdate = new ArrayList<>();
        settingsToUpdate.add(new Setting("business_name", etBusinessName.getText().toString()));
        settingsToUpdate.add(new Setting("business_phone", etBusinessPhone.getText().toString()));
        settingsToUpdate.add(new Setting("business_address", etBusinessAddress.getText().toString()));
        settingsToUpdate.add(new Setting("currency_code", etCurrencyCode.getText().toString()));
        settingsToUpdate.add(new Setting("tax_enabled", String.valueOf(swEnableTax.isChecked())));
        settingsToUpdate.add(new Setting("tax_rate", etTaxRate.getText().toString()));
        settingsToUpdate.add(new Setting("low_stock_limit", etLowStockLimit.getText().toString()));
        settingsToUpdate.add(new Setting("notifications_low_stock", String.valueOf(swLowStockAlerts.isChecked())));
        settingsToUpdate.add(new Setting("sales_discounts_enabled", String.valueOf(swEnableDiscounts.isChecked())));
        settingsToUpdate.add(new Setting("sales_price_editing", String.valueOf(swPriceEditing.isChecked())));
        settingsToUpdate.add(new Setting("receipt_message", etReceiptMessage.getText().toString()));
        settingsToUpdate.add(new Setting("date_format", spDateFormat.getSelectedItem().toString()));
        settingsToUpdate.add(new Setting("appearance_theme", spTheme.getSelectedItem().toString()));

        settingViewModel.updateSettings(settingsToUpdate);
        Toast.makeText(getContext(), "Settings saved successfully", Toast.LENGTH_SHORT).show();
    }
}
