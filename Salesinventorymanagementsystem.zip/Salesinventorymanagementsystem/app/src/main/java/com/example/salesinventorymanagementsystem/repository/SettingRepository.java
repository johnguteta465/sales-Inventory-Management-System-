package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.SettingDao;
import com.example.salesinventorymanagementsystem.model.Setting;

import java.util.List;

public class SettingRepository {
    private SettingDao settingDao;
    private LiveData<List<Setting>> allSettings;

    public SettingRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        settingDao = db.settingDao();
        allSettings = settingDao.getAllSettings();
    }

    public LiveData<List<Setting>> getAllSettings() {
        return allSettings;
    }

    public List<Setting> getAllSettingsSync() {
        return settingDao.getAllSettingsSync();
    }

    public LiveData<Setting> getSetting(String key) {
        return settingDao.getSetting(key);
    }

    public void insert(Setting setting) {
        AppDatabase.databaseWriteExecutor.execute(() -> settingDao.insert(setting));
    }

    public void insertAll(List<Setting> settings) {
        AppDatabase.databaseWriteExecutor.execute(() -> settingDao.insertAll(settings));
    }
}
