package com.example.salesinventorymanagementsystem.ui.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.ui.adapters.MyOrdersAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;

import java.util.ArrayList;
import java.util.List;

public class MyOrdersFragment extends Fragment {

    private SaleViewModel saleViewModel;
    private MyOrdersAdapter adapter;
    private TextView tvEmptyOrders;
    private RecyclerView rvOrders;
    private int currentUserId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_orders, container, false);

        SharedPreferences prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        currentUserId = prefs.getInt("USER_ID", -1);

        rvOrders = view.findViewById(R.id.rvMyOrders);
        tvEmptyOrders = view.findViewById(R.id.tvEmptyOrders);
        
        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new MyOrdersAdapter(sale -> {
            Bundle args = new Bundle();
            args.putInt("saleId", sale.getId());
            Navigation.findNavController(view).navigate(R.id.nav_order_details, args);
        });
        rvOrders.setAdapter(adapter);

        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);

        saleViewModel.getAllSales().observe(getViewLifecycleOwner(), sales -> {
            List<Sale> customerOrders = new ArrayList<>();
            for (Sale sale : sales) {
                if (sale.getCustomerId() == currentUserId) {
                    customerOrders.add(sale);
                }
            }
            
            if (customerOrders.isEmpty()) {
                tvEmptyOrders.setVisibility(View.VISIBLE);
                rvOrders.setVisibility(View.GONE);
            } else {
                tvEmptyOrders.setVisibility(View.GONE);
                rvOrders.setVisibility(View.VISIBLE);
                adapter.submitList(customerOrders);
            }
        });

        return view;
    }
}
