package com.example.salesinventorymanagementsystem.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.salesinventorymanagementsystem.model.User;
import com.example.salesinventorymanagementsystem.repository.UserRepository;

import java.util.List;

public class UserViewModel extends AndroidViewModel {
    private UserRepository repository;
    private LiveData<List<User>> allUsers;

    public UserViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
        allUsers = repository.getAllUsers();
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    public long insert(User user) {
        return repository.insert(user);
    }

    public void update(User user) {
        repository.update(user);
    }

    public User getUserById(int id) {
        return repository.getUserById(id);
    }

    public User login(String email, String password) {
        return repository.login(email, password);
    }

    public int getUserCount() {
        return repository.getUserCount();
    }
}
