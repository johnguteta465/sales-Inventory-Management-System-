package com.example.salesinventorymanagementsystem.ui.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.Setting;
import com.example.salesinventorymanagementsystem.ui.adapters.CartAdapter;
import com.example.salesinventorymanagementsystem.ui.adapters.CategoryBrowseAdapter;
import com.example.salesinventorymanagementsystem.ui.adapters.MyOrdersAdapter;
import com.example.salesinventorymanagementsystem.ui.adapters.ProductBrowseAdapter;
import com.example.salesinventorymanagementsystem.ui.adapters.RecentSalesAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CartViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.CategoryViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SettingViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.UserViewModel;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class DashboardFragment extends Fragment {

    private SaleViewModel saleViewModel;
    private ProductViewModel productViewModel;
    private UserViewModel userViewModel;
    private SettingViewModel settingViewModel;
    private CategoryViewModel categoryViewModel;
    private CartViewModel cartViewModel;

    // Admin Dashboard Views
    private TextView tvWelcomeBack, tvTotalUsersHeader, tvTotalProductsHeader, tvTotalSalesHeader, tvTotalRevenueHeader;
    private View btnManageUsers, btnManageProducts, btnManageCustomers, btnSalesManagement, btnSalesReports;
    private View btnInventoryReports, btnLowStockAlerts, btnSystemSettings;
    private TextView tvTodaySalesVal, tvMonthRevenueVal, tvTotalProductsVal, tvLowStockVal;
    private RecentSalesAdapter recentSalesAdapter;

    // Cashier Dashboard Views
    private TextView tvCashierTodaySales, tvCashierTotalTx, tvCashierItemsSold, tvCashierLowStock;
    private TextView tvPreviewSubtotal, tvPreviewTax, tvPreviewTotal;
    private RecentSalesAdapter cashierRecentSalesAdapter;
    private CartAdapter cartPreviewAdapter;
    private List<Product> allProducts;

    // Customer Dashboard Views
    private TextView tvCustomerDashboardMessage;
    private RecyclerView rvCustomerCategories, rvFeaturedProducts, rvCustomerRecentOrders;
    private CategoryBrowseAdapter categoryBrowseAdapter;
    private ProductBrowseAdapter productBrowseAdapter;
    private MyOrdersAdapter myOrdersAdapter;

    private final Map<String, String> settings = new HashMap<>();
    private List<Sale> allSalesList;
    private String userRole;
    private int userId;

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if (result.getContents() != null) {
                    handleBarcodeScan(result.getContents());
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        SharedPreferences prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        userRole = prefs.getString("USER_ROLE", "Admin");
        userId = prefs.getInt("USER_ID", -1);

        View view;
        if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
            view = inflater.inflate(R.layout.fragment_dashboard, container, false);
            initAdminViews(view);
        } else if ("Cashier".equalsIgnoreCase(userRole)) {
            view = inflater.inflate(R.layout.fragment_cashier_dashboard, container, false);
            initCashierViews(view);
        } else if ("Customer".equalsIgnoreCase(userRole)) {
            view = inflater.inflate(R.layout.fragment_customer_dashboard, container, false);
            initCustomerViews(view);
        } else {
            // Fallback for others
            view = inflater.inflate(R.layout.fragment_dashboard, container, false);
            initAdminViews(view);
        }

        initViewModels();
        setupObservers();
        return view;
    }

    private void initViewModels() {
        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);
        categoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
        cartViewModel = new ViewModelProvider(requireActivity()).get(CartViewModel.class);
    }

    private void initAdminViews(View view) {
        tvWelcomeBack = view.findViewById(R.id.tvWelcomeBack);
        tvTotalUsersHeader = view.findViewById(R.id.tvTotalUsersHeader);
        tvTotalProductsHeader = view.findViewById(R.id.tvTotalProductsHeader);
        tvTotalSalesHeader = view.findViewById(R.id.tvTotalSalesHeader);
        tvTotalRevenueHeader = view.findViewById(R.id.tvTotalRevenueHeader);

        String name = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).getString("USER_NAME", "Admin");
        if (tvWelcomeBack != null) tvWelcomeBack.setText("Welcome Back, " + name + "!");

        btnManageUsers = view.findViewById(R.id.btnManageUsers);
        btnManageProducts = view.findViewById(R.id.btnManageProducts);
        btnManageCustomers = view.findViewById(R.id.btnManageCustomers);
        btnSalesManagement = view.findViewById(R.id.btnSalesManagement);
        btnSalesReports = view.findViewById(R.id.btnSalesReports);
        btnInventoryReports = view.findViewById(R.id.btnInventoryReports);
        btnLowStockAlerts = view.findViewById(R.id.btnLowStockAlerts);
        btnSystemSettings = view.findViewById(R.id.btnSystemSettings);

        if ("Inventory Manager".equalsIgnoreCase(userRole) && btnManageUsers != null) {
            btnManageUsers.setVisibility(View.GONE);
        }

        View mTodaySales = view.findViewById(R.id.metricTodaySales);
        if (mTodaySales != null) tvTodaySalesVal = mTodaySales.findViewById(R.id.tvMetricValue);
        
        View mMonthRev = view.findViewById(R.id.metricMonthRevenue);
        if (mMonthRev != null) tvMonthRevenueVal = mMonthRev.findViewById(R.id.tvMetricValue);

        View mTotalProd = view.findViewById(R.id.metricTotalProducts);
        if (mTotalProd != null) tvTotalProductsVal = mTotalProd.findViewById(R.id.tvMetricValue);

        View mLowStock = view.findViewById(R.id.metricLowStock);
        if (mLowStock != null) tvLowStockVal = mLowStock.findViewById(R.id.tvMetricValue);

        RecyclerView rvRecentSales = view.findViewById(R.id.rvRecentSalesDashboard);
        if (rvRecentSales != null) {
            rvRecentSales.setLayoutManager(new LinearLayoutManager(getContext()));
            recentSalesAdapter = new RecentSalesAdapter();
            rvRecentSales.setAdapter(recentSalesAdapter);
        }

        ImageView btnToggleTheme = view.findViewById(R.id.btnToggleThemeAdmin);
        if (btnToggleTheme != null) {
            updateThemeIcon(btnToggleTheme);
            btnToggleTheme.setOnClickListener(v -> toggleTheme());
        }
        
        setupQuickAccess();
    }

    private void initCashierViews(View view) {
        View mTodaySales = view.findViewById(R.id.metricTodaySales);
        View mTotalTx = view.findViewById(R.id.metricTotalTx);
        View mItemsSold = view.findViewById(R.id.metricItemsSold);
        View mLowStock = view.findViewById(R.id.metricLowStock);

        if (mTodaySales != null) tvCashierTodaySales = mTodaySales.findViewById(R.id.tvMetricValue);
        if (mTotalTx != null) tvCashierTotalTx = mTotalTx.findViewById(R.id.tvMetricValue);
        if (mItemsSold != null) tvCashierItemsSold = mItemsSold.findViewById(R.id.tvMetricValue);
        if (mLowStock != null) tvCashierLowStock = mLowStock.findViewById(R.id.tvMetricValue);

        setupCashierAction(view.findViewById(R.id.actionNewSale), "New Sale", R.drawable.ic_cart, R.id.nav_new_sale);
        setupCashierAction(view.findViewById(R.id.actionScan), "Scan Barcode", R.drawable.ic_barcode, R.id.nav_new_sale);
        setupCashierAction(view.findViewById(R.id.actionNewCustomer), "New Customer", android.R.drawable.ic_input_add, R.id.nav_customers);
        setupCashierAction(view.findViewById(R.id.actionHistory), "Sales History", android.R.drawable.ic_menu_recent_history, R.id.nav_sales);

        RecyclerView rvRecent = view.findViewById(R.id.rvCashierRecentSales);
        if (rvRecent != null) {
            rvRecent.setLayoutManager(new LinearLayoutManager(getContext()));
            cashierRecentSalesAdapter = new RecentSalesAdapter();
            rvRecent.setAdapter(cashierRecentSalesAdapter);
        }

        RecyclerView rvPreview = view.findViewById(R.id.rvCurrentSalePreview);
        if (rvPreview != null) {
            rvPreview.setLayoutManager(new LinearLayoutManager(getContext()));
            cartPreviewAdapter = new CartAdapter(new CartAdapter.OnCartItemChangeListener() {
                @Override public void onQuantityChange(int p, int q) { cartViewModel.updateQuantity(p, q); }
                @Override public void onRemove(int p) { cartViewModel.removeItem(p); }
            });
            rvPreview.setAdapter(cartPreviewAdapter);
        }

        tvPreviewSubtotal = view.findViewById(R.id.tvPreviewSubtotal);
        tvPreviewTax = view.findViewById(R.id.tvPreviewTax);
        tvPreviewTotal = view.findViewById(R.id.tvPreviewTotal);
        
        View btnProceed = view.findViewById(R.id.btnProceedToPayment);
        if (btnProceed != null) {
            btnProceed.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.nav_new_sale));
        }

        ImageView btnToggleTheme = view.findViewById(R.id.btnToggleThemeCashier);
        if (btnToggleTheme != null) {
            updateThemeIcon(btnToggleTheme);
            btnToggleTheme.setOnClickListener(v -> toggleTheme());
        }
    }

    private void setupCashierAction(View view, String title, int icon, int destination) {
        if (view == null) return;
        TextView tv = view.findViewById(R.id.tvActionTitle);
        ImageView iv = view.findViewById(R.id.ivActionIcon);
        if (tv != null) tv.setText(title);
        if (iv != null) iv.setImageResource(icon);
        view.setOnClickListener(v -> Navigation.findNavController(v).navigate(destination));
    }

    private void initCustomerViews(View view) {
        TextView tvWelcome = view.findViewById(R.id.tvWelcomeCustomer);
        String name = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).getString("USER_NAME", "User");
        if (tvWelcome != null) tvWelcome.setText("Welcome Back, " + name + "! 👋");

        tvCustomerDashboardMessage = view.findViewById(R.id.tvCustomerDashboardMessage);
        rvCustomerCategories = view.findViewById(R.id.rvCustomerCategories);
        rvFeaturedProducts = view.findViewById(R.id.rvFeaturedProducts);
        rvCustomerRecentOrders = view.findViewById(R.id.rvCustomerRecentOrders);

        if (rvCustomerCategories != null) {
            rvCustomerCategories.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
            categoryBrowseAdapter = new CategoryBrowseAdapter();
            rvCustomerCategories.setAdapter(categoryBrowseAdapter);
        }

        if (rvFeaturedProducts != null) {
            rvFeaturedProducts.setLayoutManager(new GridLayoutManager(getContext(), 2));
            productBrowseAdapter = new ProductBrowseAdapter(new ProductBrowseAdapter.OnProductClickListener() {
                @Override public void onProductClick(Product p) {}
                @Override public void onAddToCartClick(Product p) {
                    cartViewModel.addToCart(p);
                    Toast.makeText(getContext(), "Added to cart", Toast.LENGTH_SHORT).show();
                }
            });
            rvFeaturedProducts.setAdapter(productBrowseAdapter);
        }

        if (rvCustomerRecentOrders != null) {
            rvCustomerRecentOrders.setLayoutManager(new LinearLayoutManager(getContext()));
            myOrdersAdapter = new MyOrdersAdapter(sale -> {
                Bundle args = new Bundle();
                args.putInt("saleId", sale.getId());
                Navigation.findNavController(view).navigate(R.id.nav_order_details, args);
            });
            rvCustomerRecentOrders.setAdapter(myOrdersAdapter);
        }

        ImageView btnToggleTheme = view.findViewById(R.id.btnToggleThemeCustomer);
        if (btnToggleTheme != null) {
            updateThemeIcon(btnToggleTheme);
            btnToggleTheme.setOnClickListener(v -> toggleTheme());
        }

        ImageView btnScan = view.findViewById(R.id.btnBarcodeScannerCustomer);
        if (btnScan != null) {
            btnScan.setOnClickListener(v -> barcodeLauncher.launch(new ScanOptions()));
        }
    }

    private void handleBarcodeScan(String barcode) {
        if (allProducts != null) {
            Product found = allProducts.stream()
                    .filter(p -> barcode.equals(p.getBarcode()))
                    .findFirst()
                    .orElse(null);

            if (found != null) {
                if ("Customer".equalsIgnoreCase(userRole)) {
                    cartViewModel.addToCart(found);
                    Toast.makeText(getContext(), found.getName() + " added to cart", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Product not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateThemeIcon(ImageView btn) {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE);
        boolean isDarkMode = sharedPreferences.getBoolean("isDarkMode", false);
        if (isDarkMode) {
            btn.setImageResource(android.R.drawable.ic_menu_day);
        } else {
            btn.setImageResource(android.R.drawable.ic_menu_recent_history);
        }
    }

    private void toggleTheme() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE);
        boolean isDarkMode = sharedPreferences.getBoolean("isDarkMode", false);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            editor.putBoolean("isDarkMode", false);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            editor.putBoolean("isDarkMode", true);
        }
        editor.apply();
    }

    private void setupQuickAccess() {
        configureQuickAccess(btnManageUsers, "Users", "Manage accounts", R.drawable.ic_dashboard, R.color.metric_blue_bg, R.id.nav_users);
        configureQuickAccess(btnManageProducts, "Products", "Inventory list", R.drawable.ic_products, R.color.metric_green_soft, R.id.nav_products);
        configureQuickAccess(btnManageCustomers, "Customers", "Client directory", R.drawable.ic_cart, R.color.metric_blue_bg, R.id.nav_customers);
        configureQuickAccess(btnSalesManagement, "Sales", "Transactions", R.drawable.ic_sales, R.color.metric_yellow_bg, R.id.nav_sales);
        configureQuickAccess(btnSalesReports, "Reports", "Sales analysis", R.drawable.ic_sales, R.color.metric_yellow_bg, R.id.nav_sales);
        configureQuickAccess(btnInventoryReports, "Inventory", "Stock logs", R.drawable.ic_products, R.color.metric_blue_bg, R.id.nav_inventory);
        configureQuickAccess(btnLowStockAlerts, "Alerts", "Restock needs", R.drawable.ic_products, R.color.metric_green_soft, R.id.nav_low_stock);
        configureQuickAccess(btnSystemSettings, "Settings", "System config", R.drawable.ic_dashboard, R.color.metric_blue_bg, R.id.nav_settings);
    }

    private void configureQuickAccess(View view, String title, String desc, int icon, int bgColor, int destinationId) {
        if (view == null) return;
        TextView tvTitle = view.findViewById(R.id.tvQuickAccessTitle);
        TextView tvDesc = view.findViewById(R.id.tvQuickAccessDesc);
        ImageView ivIcon = view.findViewById(R.id.ivQuickAccessIcon);
        View llBg = view.findViewById(R.id.llQuickAccessBg);

        if (tvTitle != null) tvTitle.setText(title);
        if (tvDesc != null) tvDesc.setText(desc);
        if (ivIcon != null) ivIcon.setImageResource(icon);
        if (llBg != null) llBg.setBackgroundColor(ContextCompat.getColor(requireContext(), bgColor));

        view.setOnClickListener(v -> Navigation.findNavController(v).navigate(destinationId));
    }

    private void setupObservers() {
        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            if (products != null) {
                allProducts = products.stream().map(pwc -> pwc.product).collect(Collectors.toList());
                updateCartPreview();
                if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
                    if (tvTotalProductsHeader != null) tvTotalProductsHeader.setText(String.valueOf(products.size()));
                    if (tvTotalProductsVal != null) tvTotalProductsVal.setText(String.valueOf(products.size()));
                }
                if (productBrowseAdapter != null) {
                    productBrowseAdapter.submitList(products); // Correctly passing List<ProductWithCategory>
                }
            }
        });

        productViewModel.getLowStockProducts().observe(getViewLifecycleOwner(), lowStock -> {
            if (lowStock != null) {
                if (("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) && tvLowStockVal != null) 
                    tvLowStockVal.setText(String.valueOf(lowStock.size()));
                if ("Cashier".equalsIgnoreCase(userRole) && tvCashierLowStock != null) 
                    tvCashierLowStock.setText(String.valueOf(lowStock.size()));
            }
        });

        saleViewModel.getAllSales().observe(getViewLifecycleOwner(), sales -> {
            if (sales != null) {
                allSalesList = sales;
                refreshMetrics();
                if ("Customer".equalsIgnoreCase(userRole) && myOrdersAdapter != null) {
                    List<Sale> mySales = sales.stream().filter(s -> s.getCustomerId() == userId).collect(Collectors.toList());
                    myOrdersAdapter.submitList(mySales);
                }
            }
        });

        settingViewModel.getAllSettings().observe(getViewLifecycleOwner(), settingsList -> {
            if (settingsList != null) {
                for (Setting s : settingsList) settings.put(s.getKey(), s.getValue());
                refreshMetrics();
                updateCartPreview();
                updateCustomerDashboardMessage();
            }
        });

        if ("Cashier".equalsIgnoreCase(userRole)) {
            cartViewModel.getCartItems().observe(getViewLifecycleOwner(), items -> updateCartPreview());
        }

        categoryViewModel.getAllCategories().observe(getViewLifecycleOwner(), categories -> {
            if (categoryBrowseAdapter != null) categoryBrowseAdapter.submitList(categories);
        });
    }

    private void updateCustomerDashboardMessage() {
        if ("Customer".equalsIgnoreCase(userRole) && tvCustomerDashboardMessage != null) {
            String message = settings.getOrDefault("receipt_message", "Find the best products at best prices");
            tvCustomerDashboardMessage.setText(message);
        }
    }

    private void updateCartPreview() {
        if (!"Cashier".equalsIgnoreCase(userRole) || cartPreviewAdapter == null || allProducts == null) return;
        cartViewModel.getCartItems().observe(getViewLifecycleOwner(), items -> {
            cartPreviewAdapter.setItems(items, allProducts);
            double subtotal = items.stream().mapToDouble(i -> i.getUnitPrice() * i.getQuantity()).sum();
            String taxStr = settings.getOrDefault("tax_rate", "15");
            double taxRate = 15;
            try { taxRate = Double.parseDouble(taxStr); } catch (Exception ignored) {}
            double tax = subtotal * (taxRate / 100.0);
            String currency = settings.getOrDefault("currency_code", "ETB");
            if (tvPreviewSubtotal != null) tvPreviewSubtotal.setText(String.format(Locale.getDefault(), "%s %,.2f", currency, subtotal));
            if (tvPreviewTax != null) tvPreviewTax.setText(String.format(Locale.getDefault(), "%s %,.2f", currency, tax));
            if (tvPreviewTotal != null) tvPreviewTotal.setText(String.format(Locale.getDefault(), "%s %,.2f", currency, subtotal + tax));
        });
    }

    private void refreshMetrics() {
        if (allSalesList == null) return;
        String currency = settings.getOrDefault("currency_code", "ETB");
        if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
            double totalRev = allSalesList.stream().mapToDouble(Sale::getTotalAmount).sum();
            if (tvTotalSalesHeader != null) tvTotalSalesHeader.setText(String.valueOf(allSalesList.size()));
            if (tvTotalRevenueHeader != null) tvTotalRevenueHeader.setText(String.format(Locale.getDefault(), "%s%,.0f", currency, totalRev));
            if (recentSalesAdapter != null) recentSalesAdapter.setSales(allSalesList);
        } else if ("Cashier".equalsIgnoreCase(userRole)) {
            new Thread(() -> {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0);
                long todayStart = cal.getTimeInMillis();
                double rev = saleViewModel.getRevenueToday(todayStart, userId);
                int txCount = saleViewModel.getTransactionCountToday(todayStart, userId);
                int itemsCount = saleViewModel.getItemsSoldToday(todayStart, userId);
                List<Sale> myRecent = allSalesList.stream().filter(s -> s.getUserId() == userId).limit(10).collect(Collectors.toList());
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (tvCashierTodaySales != null) tvCashierTodaySales.setText(String.format(Locale.getDefault(), "%s %,.2f", currency, rev));
                        if (tvCashierTotalTx != null) tvCashierTotalTx.setText(String.valueOf(txCount));
                        if (tvCashierItemsSold != null) tvCashierItemsSold.setText(String.valueOf(itemsCount));
                        if (cashierRecentSalesAdapter != null) cashierRecentSalesAdapter.setSales(myRecent);
                    });
                }
            }).start();
        }
    }
}
