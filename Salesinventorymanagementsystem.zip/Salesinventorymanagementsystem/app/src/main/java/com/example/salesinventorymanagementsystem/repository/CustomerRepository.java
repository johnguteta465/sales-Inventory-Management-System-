package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.CustomerDao;
import com.example.salesinventorymanagementsystem.model.Customer;
import java.util.List;

public class CustomerRepository {
    private CustomerDao customerDao;
    private LiveData<List<Customer>> allCustomers;

    public CustomerRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        customerDao = db.customerDao();
        allCustomers = customerDao.getAllCustomers();
    }

    public LiveData<List<Customer>> getAllCustomers() {
        return allCustomers;
    }

    public void insert(Customer customer) {
        AppDatabase.databaseWriteExecutor.execute(() -> customerDao.insert(customer));
    }

    public void update(Customer customer) {
        AppDatabase.databaseWriteExecutor.execute(() -> customerDao.update(customer));
    }

    public void delete(Customer customer) {
        AppDatabase.databaseWriteExecutor.execute(() -> customerDao.delete(customer));
    }

    public LiveData<List<Customer>> searchCustomers(String query) {
        return customerDao.searchCustomers("%" + query + "%");
    }
}
