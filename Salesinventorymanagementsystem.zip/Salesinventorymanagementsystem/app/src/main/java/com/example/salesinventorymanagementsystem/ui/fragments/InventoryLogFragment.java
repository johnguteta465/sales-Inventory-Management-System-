package com.example.salesinventorymanagementsystem.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.ui.adapters.InventoryLogAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.InventoryLogViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class InventoryLogFragment extends Fragment {

    private InventoryLogViewModel inventoryLogViewModel;
    private ProductViewModel productViewModel;
    private InventoryLogAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory_log, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.rvInventoryLogs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new InventoryLogAdapter();
        recyclerView.setAdapter(adapter);

        inventoryLogViewModel = new ViewModelProvider(this).get(InventoryLogViewModel.class);
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);

        inventoryLogViewModel.getAllLogs().observe(getViewLifecycleOwner(), logs -> {
            adapter.submitList(logs);
        });

        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            adapter.setProducts(products.stream().map(pwc -> pwc.product).collect(Collectors.toList()));
        });

        return view;
    }
}
