package com.example.salesinventorymanagementsystem.ui.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Category;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.ui.adapters.ProductAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CategoryViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class ProductListFragment extends Fragment implements ProductAdapter.OnProductClickListener {

    private ProductViewModel productViewModel;
    private CategoryViewModel categoryViewModel;
    private ProductAdapter adapter;
    private List<Category> categoryList = new ArrayList<>();
    
    private Uri selectedImageUri;
    private ImageView dialogImageView;
    private TextInputEditText etBarcode;
    private boolean showLowStockOnly = false;
    private String userRole;

    private final ActivityResultLauncher<String> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    if (dialogImageView != null) {
                        Glide.with(this).load(uri).into(dialogImageView);
                    }
                }
            }
    );

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if (result.getContents() != null) {
                    if (etBarcode != null) {
                        etBarcode.setText(result.getContents());
                    }
                }
            });

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            showLowStockOnly = getArguments().getBoolean("showLowStockOnly", false);
        }
        SharedPreferences prefs = requireContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        userRole = prefs.getString("USER_ROLE", "Customer");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.rvProducts);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ProductAdapter(this, userRole);
        recyclerView.setAdapter(adapter);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        categoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);

        if (showLowStockOnly) {
            productViewModel.getLowStockProducts().observe(getViewLifecycleOwner(), products -> {
                productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), allProducts -> {
                    List<ProductWithCategory> filtered = allProducts.stream()
                            .filter(pwc -> products.stream().anyMatch(lp -> lp.getId() == pwc.product.getId()))
                            .collect(Collectors.toList());
                    adapter.submitList(filtered);
                });
            });
        } else {
            productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
                adapter.submitList(products);
            });
        }

        categoryViewModel.getAllCategories().observe(getViewLifecycleOwner(), categories -> {
            categoryList = categories;
        });

        FloatingActionButton fab = view.findViewById(R.id.fabAddProduct);
        
        // UPDATED ROLE RESTRICTION: Admins AND Inventory Managers can add products
        if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
            fab.setVisibility(View.VISIBLE);
            fab.setOnClickListener(v -> showProductDialog(null));
        } else {
            fab.setVisibility(View.GONE);
        }

        return view;
    }

    private String saveImageToInternalStorage(Uri uri) {
        if (uri == null) return null;
        try {
            Context context = requireContext();
            String fileName = "product_" + UUID.randomUUID().toString() + ".jpg";
            File file = new File(context.getFilesDir(), fileName);
            
            try (InputStream inputStream = context.getContentResolver().openInputStream(uri);
                 FileOutputStream outputStream = new FileOutputStream(file)) {
                
                byte[] buffer = new byte[1024];
                int read;
                while ((read = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, read);
                }
            }
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return uri.toString();
        }
    }

    private void showProductDialog(Product product) {
        // ALLOW Admin or Inventory Manager
        if (!"Admin".equalsIgnoreCase(userRole) && !"Inventory Manager".equalsIgnoreCase(userRole)) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_product, null);
        builder.setView(dialogView);

        dialogImageView = dialogView.findViewById(R.id.ivProductDialog);
        Button btnSelectImage = dialogView.findViewById(R.id.btnSelectImage);
        TextInputEditText etName = dialogView.findViewById(R.id.etProductName);
        Spinner spCategory = dialogView.findViewById(R.id.spCategory);
        TextInputEditText etPrice = dialogView.findViewById(R.id.etProductPrice);
        TextInputEditText etStock = dialogView.findViewById(R.id.etProductStock);
        etBarcode = dialogView.findViewById(R.id.etProductBarcode);
        View btnScan = dialogView.findViewById(R.id.btnScanBarcode);

        updateSpinner(spCategory, product);

        if (product != null) {
            builder.setTitle("Edit Product");
            etName.setText(product.getName());
            etPrice.setText(String.valueOf(product.getPrice()));
            etStock.setText(String.valueOf(product.getStockQuantity()));
            etBarcode.setText(product.getBarcode());
            if (product.getImageUri() != null) {
                Glide.with(this).load(product.getImageUri()).into(dialogImageView);
            }
        } else {
            builder.setTitle("Add Product");
            selectedImageUri = null;
        }

        btnSelectImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));
        btnScan.setOnClickListener(v -> barcodeLauncher.launch(new ScanOptions()));

        builder.setPositiveButton("Save", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String priceStr = etPrice.getText().toString().trim();
            String stockStr = etStock.getText().toString().trim();
            String barcode = etBarcode.getText().toString().trim();
            int categoryIndex = spCategory.getSelectedItemPosition();

            if (categoryList.isEmpty()) {
                Toast.makeText(getContext(), "Please create a category first", Toast.LENGTH_SHORT).show();
                return;
            }

            if (name.isEmpty() || priceStr.isEmpty() || stockStr.isEmpty()) {
                Toast.makeText(getContext(), "Please fill required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double price = Double.parseDouble(priceStr);
            int stock = Integer.parseInt(stockStr);
            int categoryId = categoryList.get(categoryIndex).getId();

            String finalImageUri = (product != null) ? product.getImageUri() : null;
            if (selectedImageUri != null && (product == null || !selectedImageUri.toString().equals(product.getImageUri()))) {
                finalImageUri = saveImageToInternalStorage(selectedImageUri);
            }

            if (product == null) {
                Product newProduct = new Product(name, categoryId, price, stock, barcode, finalImageUri);
                productViewModel.insert(newProduct);
            } else {
                product.setName(name);
                product.setCategoryId(categoryId);
                product.setPrice(price);
                product.setStockQuantity(stock);
                product.setBarcode(barcode);
                product.setImageUri(finalImageUri);
                productViewModel.update(product);
            }
        });
        
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void updateSpinner(Spinner spinner, Product product) {
        List<String> categoryNames = new ArrayList<>();
        if (categoryList.isEmpty()) {
            categoryNames.add("No categories available");
        } else {
            for (Category c : categoryList) {
                categoryNames.add(c.getName());
            }
        }
        
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categoryNames);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        if (product != null && !categoryList.isEmpty()) {
            for (int i = 0; i < categoryList.size(); i++) {
                if (categoryList.get(i).getId() == product.getCategoryId()) {
                    spinner.setSelection(i);
                    break;
                }
            }
        }
    }

    @Override
    public void onEditClick(Product product) {
        if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
            showProductDialog(product);
        } else {
            Toast.makeText(getContext(), "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDeleteClick(Product product) {
        if ("Admin".equalsIgnoreCase(userRole) || "Inventory Manager".equalsIgnoreCase(userRole)) {
            new AlertDialog.Builder(getContext())
                    .setTitle("Delete Product")
                    .setMessage("Are you sure?")
                    .setPositiveButton("Yes", (dialog, which) -> productViewModel.delete(product))
                    .setNegativeButton("No", null)
                    .show();
        } else {
            Toast.makeText(getContext(), "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
