package com.example.salesinventorymanagementsystem.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.salesinventorymanagementsystem.model.Setting;
import com.example.salesinventorymanagementsystem.repository.SettingRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingViewModel extends AndroidViewModel {
    private SettingRepository repository;
    private LiveData<List<Setting>> allSettings;

    public SettingViewModel(Application application) {
        super(application);
        repository = new SettingRepository(application);
        allSettings = repository.getAllSettings();
    }

    public LiveData<List<Setting>> getAllSettings() {
        return allSettings;
    }

    public Map<String, String> getAllSettingsAsMapSync() {
        List<Setting> settings = repository.getAllSettingsSync();
        Map<String, String> settingsMap = new HashMap<>();
        if (settings != null) {
            for (Setting setting : settings) {
                settingsMap.put(setting.getKey(), setting.getValue());
            }
        }
        return settingsMap;
    }

    public LiveData<Setting> getSetting(String key) {
        return repository.getSetting(key);
    }

    public void updateSetting(String key, String value) {
        repository.insert(new Setting(key, value));
    }

    public void updateSettings(List<Setting> settings) {
        repository.insertAll(settings);
    }
}
