package com.example.salesinventorymanagementsystem.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.salesinventorymanagementsystem.model.InventoryLog;

import java.util.List;

@Dao
public interface InventoryLogDao {
    @Insert
    void insert(InventoryLog log);

    @Query("SELECT * FROM inventory_logs WHERE productId = :productId ORDER BY timestamp DESC")
    LiveData<List<InventoryLog>> getLogsForProduct(int productId);

    @Query("SELECT * FROM inventory_logs ORDER BY timestamp DESC")
    LiveData<List<InventoryLog>> getAllLogs();
}
