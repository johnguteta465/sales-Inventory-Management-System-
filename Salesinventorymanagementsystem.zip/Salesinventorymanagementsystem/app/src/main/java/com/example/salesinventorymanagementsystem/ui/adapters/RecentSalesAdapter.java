package com.example.salesinventorymanagementsystem.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Sale;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RecentSalesAdapter extends RecyclerView.Adapter<RecentSalesAdapter.ViewHolder> {

    private List<Sale> sales = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    public void setSales(List<Sale> sales) {
        this.sales = sales;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recent_sale_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Sale sale = sales.get(position);
        Context context = holder.itemView.getContext();

        holder.tvId.setText(String.format(Locale.getDefault(), "INV-%04d", sale.getId()));
        holder.tvDate.setText(sdf.format(new Date(sale.getTimestamp())));
        holder.tvTotal.setText(String.format(Locale.getDefault(), "ETB %.2f", sale.getTotalAmount()));

        // Logic for payment method tags (Mocked for demo as in the screenshot)
        if (sale.getId() % 3 == 0) {
            holder.tvPaymentMethod.setText("Telebirr");
            holder.tvPaymentMethod.setBackgroundResource(R.drawable.tag_tele_bg);
            holder.tvPaymentMethod.setTextColor(context.getColor(R.color.tag_tele_text));
        } else if (sale.getId() % 2 == 0) {
            holder.tvPaymentMethod.setText("Card");
            holder.tvPaymentMethod.setBackgroundResource(R.drawable.tag_card_bg);
            holder.tvPaymentMethod.setTextColor(context.getColor(R.color.tag_card_text));
        } else {
            holder.tvPaymentMethod.setText("Cash");
            holder.tvPaymentMethod.setBackgroundResource(R.drawable.tag_cash_bg);
            holder.tvPaymentMethod.setTextColor(context.getColor(R.color.tag_cash_text));
        }
    }

    @Override
    public int getItemCount() {
        return Math.min(sales.size(), 10);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvId, tvDate, tvPaymentMethod, tvTotal;
        ImageView ivRowIcon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvRowId);
            tvDate = itemView.findViewById(R.id.tvRowDate);
            tvPaymentMethod = itemView.findViewById(R.id.tvPaymentMethod);
            tvTotal = itemView.findViewById(R.id.tvRowTotal);
            ivRowIcon = itemView.findViewById(R.id.ivRowIcon);
        }
    }
}
