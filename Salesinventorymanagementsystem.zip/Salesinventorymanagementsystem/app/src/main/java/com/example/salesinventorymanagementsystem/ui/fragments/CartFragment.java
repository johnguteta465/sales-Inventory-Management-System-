package com.example.salesinventorymanagementsystem.ui.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.ui.adapters.CartAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CartViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CartFragment extends Fragment implements CartAdapter.OnCartItemChangeListener {

    private CartViewModel cartViewModel;
    private ProductViewModel productViewModel;
    private SaleViewModel saleViewModel;
    private CartAdapter cartAdapter;
    private TextView tvTotal;
    private View llEmptyCart;
    private RadioGroup rgPaymentMethod;
    private LinearLayout llTelebirrInfo, llBankInfo, llCashInfo;
    private View tilTransactionRef;
    private EditText etTransactionRef;
    
    private List<Product> allProducts = new ArrayList<>();
    private int currentUserId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        SharedPreferences prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        currentUserId = prefs.getInt("USER_ID", -1);

        tvTotal = view.findViewById(R.id.tvCartTotal);
        llEmptyCart = view.findViewById(R.id.llEmptyCart);
        rgPaymentMethod = view.findViewById(R.id.rgPaymentMethod);
        
        llTelebirrInfo = view.findViewById(R.id.llTelebirrInfo);
        llBankInfo = view.findViewById(R.id.llBankInfo);
        llCashInfo = view.findViewById(R.id.llCashInfo);
        tilTransactionRef = view.findViewById(R.id.tilTransactionRef);
        etTransactionRef = view.findViewById(R.id.etTransactionRef);
        
        RecyclerView rvItems = view.findViewById(R.id.rvCartItems);
        View btnCheckout = view.findViewById(R.id.btnCartCheckout);

        rvItems.setLayoutManager(new LinearLayoutManager(getContext()));
        cartAdapter = new CartAdapter(this);
        rvItems.setAdapter(cartAdapter);

        cartViewModel = new ViewModelProvider(requireActivity()).get(CartViewModel.class);
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);

        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            allProducts.clear();
            for (ProductWithCategory pwc : products) {
                allProducts.add(pwc.product);
            }
            updateAdapter();
        });

        cartViewModel.getCartItems().observe(getViewLifecycleOwner(), items -> {
            llEmptyCart.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            updateAdapter();
        });

        cartViewModel.getTotalAmount().observe(getViewLifecycleOwner(), total -> {
            tvTotal.setText(String.format(Locale.getDefault(), "ETB %,.2f", total));
        });

        // Toggle Payment Method details visibility
        rgPaymentMethod.setOnCheckedChangeListener((group, checkedId) -> {
            if (llTelebirrInfo != null) llTelebirrInfo.setVisibility(checkedId == R.id.rbTelebirr ? View.VISIBLE : View.GONE);
            if (llBankInfo != null) llBankInfo.setVisibility(checkedId == R.id.rbLocalBank ? View.VISIBLE : View.GONE);
            if (llCashInfo != null) llCashInfo.setVisibility(checkedId == R.id.rbCash ? View.VISIBLE : View.GONE);
            
            // Reference field is required for Telebirr and Bank
            if (tilTransactionRef != null) {
                tilTransactionRef.setVisibility((checkedId == R.id.rbTelebirr || checkedId == R.id.rbLocalBank) ? View.VISIBLE : View.GONE);
            }
        });

        btnCheckout.setOnClickListener(v -> handleCheckout());

        return view;
    }

    private void updateAdapter() {
        if (cartViewModel.getCartItems().getValue() != null) {
            cartAdapter.setItems(cartViewModel.getCartItems().getValue(), allProducts);
        }
    }

    @Override
    public void onQuantityChange(int position, int newQuantity) {
        cartViewModel.updateQuantity(position, newQuantity);
    }

    @Override
    public void onRemove(int position) {
        cartViewModel.removeItem(position);
    }

    private void handleCheckout() {
        if (cartViewModel.getCartItems().getValue() == null || cartViewModel.getCartItems().getValue().isEmpty()) {
            Toast.makeText(getContext(), "Cart is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentUserId == -1) {
            Toast.makeText(getContext(), "User session expired. Please login again.", Toast.LENGTH_LONG).show();
            return;
        }

        int selectedId = rgPaymentMethod.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(getContext(), "Please select a payment method", Toast.LENGTH_SHORT).show();
            return;
        }
        
        RadioButton rb = getView().findViewById(selectedId);
        String paymentMethod = rb.getText().toString();
        String ref = "";

        if (selectedId == R.id.rbTelebirr || selectedId == R.id.rbLocalBank) {
            ref = etTransactionRef.getText().toString().trim();
            if (ref.isEmpty()) {
                String type = (selectedId == R.id.rbTelebirr) ? "Telebirr Transaction ID" : "Bank Transfer Reference";
                Toast.makeText(getContext(), "Please enter the " + type, Toast.LENGTH_SHORT).show();
                return;
            }
        }

        double total = cartViewModel.getTotalAmount().getValue();

        // Process checkout
        Sale sale = new Sale(currentUserId, currentUserId, System.currentTimeMillis(), total, 0.0, 0.0, paymentMethod);
        if (!ref.isEmpty()) {
            sale.setTransactionReference(ref);
        }

        saleViewModel.processSale(sale, cartViewModel.getCartItems().getValue());

        Toast.makeText(getContext(), "Order placed successfully!", Toast.LENGTH_LONG).show();
        cartViewModel.clearCart();
        Navigation.findNavController(getView()).navigateUp();
    }
}
