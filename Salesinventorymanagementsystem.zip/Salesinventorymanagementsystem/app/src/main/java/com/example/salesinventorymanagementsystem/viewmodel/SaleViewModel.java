package com.example.salesinventorymanagementsystem.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;
import com.example.salesinventorymanagementsystem.repository.SaleRepository;
import java.util.List;

public class SaleViewModel extends AndroidViewModel {
    private SaleRepository repository;
    private LiveData<List<Sale>> allSales;

    public SaleViewModel(@NonNull Application application) {
        super(application);
        repository = new SaleRepository(application);
        allSales = repository.getAllSales();
    }

    public LiveData<List<Sale>> getAllSales() {
        return allSales;
    }

    public LiveData<List<Sale>> getSalesByCustomer(int customerId) {
        return repository.getSalesByCustomer(customerId);
    }

    public void processSale(Sale sale, List<SaleDetail> details) {
        repository.processSale(sale, details);
    }

    public void updateStatus(int saleId, String status) {
        repository.updateStatus(saleId, status);
    }

    public LiveData<List<SaleDetail>> getDetailsForSale(int saleId) {
        return repository.getDetailsForSale(saleId);
    }

    public List<SaleDetail> getDetailsForSaleSync(int saleId) {
        return repository.getDetailsForSaleSync(saleId);
    }

    public LiveData<Double> getTotalRevenue(long start, long end) {
        return repository.getTotalRevenue(start, end);
    }

    public double getRevenueToday(long startDate, int userId) {
        return repository.getRevenueToday(startDate, userId);
    }

    public int getTransactionCountToday(long startDate, int userId) {
        return repository.getTransactionCountToday(startDate, userId);
    }

    public int getItemsSoldToday(long startDate, int userId) {
        return repository.getItemsSoldToday(startDate, userId);
    }
}
