package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.InventoryLogDao;
import com.example.salesinventorymanagementsystem.model.InventoryLog;
import java.util.List;

public class InventoryLogRepository {
    private InventoryLogDao inventoryLogDao;
    private LiveData<List<InventoryLog>> allLogs;

    public InventoryLogRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        inventoryLogDao = db.inventoryLogDao();
        allLogs = inventoryLogDao.getAllLogs();
    }

    public LiveData<List<InventoryLog>> getAllLogs() {
        return allLogs;
    }

    public void insert(InventoryLog log) {
        AppDatabase.databaseWriteExecutor.execute(() -> inventoryLogDao.insert(log));
    }

    public LiveData<List<InventoryLog>> getLogsForProduct(int productId) {
        return inventoryLogDao.getLogsForProduct(productId);
    }
}
