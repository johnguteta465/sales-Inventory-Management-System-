package com.example.salesinventorymanagementsystem.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.repository.ProductRepository;
import java.util.List;

public class ProductViewModel extends AndroidViewModel {
    private ProductRepository repository;
    private LiveData<List<ProductWithCategory>> allProductsWithCategory;

    public ProductViewModel(@NonNull Application application) {
        super(application);
        repository = new ProductRepository(application);
        allProductsWithCategory = repository.getAllProductsWithCategory();
    }

    public LiveData<List<ProductWithCategory>> getAllProductsWithCategory() {
        return allProductsWithCategory;
    }

    public void insert(Product product) {
        repository.insert(product);
    }

    public void update(Product product) {
        repository.update(product);
    }

    public void delete(Product product) {
        repository.delete(product);
    }

    public Product getProductByBarcode(String barcode) {
        return repository.getProductByBarcode(barcode);
    }

    public LiveData<List<Product>> getLowStockProducts() {
        return repository.getLowStockProducts();
    }

    public void updateStock(int productId, int change) {
        repository.updateStock(productId, change);
    }
}
