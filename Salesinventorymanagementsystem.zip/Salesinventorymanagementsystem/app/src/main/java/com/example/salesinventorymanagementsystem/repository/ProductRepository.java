package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.ProductDao;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class ProductRepository {
    private ProductDao productDao;
    private LiveData<List<ProductWithCategory>> allProductsWithCategory;

    public ProductRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        productDao = db.productDao();
        allProductsWithCategory = productDao.getAllProductsWithCategory();
    }

    public LiveData<List<ProductWithCategory>> getAllProductsWithCategory() {
        return allProductsWithCategory;
    }

    public void insert(Product product) {
        AppDatabase.databaseWriteExecutor.execute(() -> productDao.insert(product));
    }

    public void update(Product product) {
        AppDatabase.databaseWriteExecutor.execute(() -> productDao.update(product));
    }

    public void delete(Product product) {
        AppDatabase.databaseWriteExecutor.execute(() -> productDao.delete(product));
    }

    public Product getProductByBarcode(String barcode) {
        Future<Product> future = AppDatabase.databaseWriteExecutor.submit(() -> productDao.getProductByBarcode(barcode));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public LiveData<List<Product>> getLowStockProducts() {
        return productDao.getLowStockProducts();
    }

    public void updateStock(int productId, int change) {
        AppDatabase.databaseWriteExecutor.execute(() -> productDao.updateStock(productId, change));
    }
}
