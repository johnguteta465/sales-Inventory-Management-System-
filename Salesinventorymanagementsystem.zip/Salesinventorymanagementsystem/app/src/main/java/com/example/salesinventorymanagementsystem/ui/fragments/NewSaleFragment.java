package com.example.salesinventorymanagementsystem.ui.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Customer;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;
import com.example.salesinventorymanagementsystem.model.Setting;
import com.example.salesinventorymanagementsystem.ui.adapters.CartAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CustomerViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SettingViewModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class NewSaleFragment extends Fragment implements CartAdapter.OnCartItemChangeListener {

    private SaleViewModel saleViewModel;
    private ProductViewModel productViewModel;
    private CustomerViewModel customerViewModel;
    private SettingViewModel settingViewModel;

    private AutoCompleteTextView acCustomer;
    private TextView tvTotal;
    private CartAdapter cartAdapter;
    private RadioGroup rgPaymentMethod;
    private View tilTransactionRef;
    private EditText etTransactionRef;

    private List<Customer> customerList = new ArrayList<>();
    private List<Product> allProducts = new ArrayList<>();
    private List<SaleDetail> cartItems = new ArrayList<>();
    private double totalAmount = 0.0;
    
    private Map<String, String> settings = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_new_sale, container, false);

        acCustomer = view.findViewById(R.id.acSaleCustomer);
        tvTotal = view.findViewById(R.id.tvSaleTotal);
        rgPaymentMethod = view.findViewById(R.id.rgPosPaymentMethod);
        tilTransactionRef = view.findViewById(R.id.tilPosTransactionRef);
        etTransactionRef = view.findViewById(R.id.etPosTransactionRef);
        
        RecyclerView rvCart = view.findViewById(R.id.rvCart);
        Button btnAddItem = view.findViewById(R.id.btnAddProductToCart);
        Button btnCheckout = view.findViewById(R.id.btnCheckout);

        rvCart.setLayoutManager(new LinearLayoutManager(getContext()));
        cartAdapter = new CartAdapter(this);
        rvCart.setAdapter(cartAdapter);

        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);

        customerViewModel.getAllCustomers().observe(getViewLifecycleOwner(), customers -> {
            customerList = customers;
            List<String> names = new ArrayList<>();
            for (Customer c : customers) names.add(c.getName());
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, names);
            acCustomer.setAdapter(adapter);
        });
        
        acCustomer.setOnClickListener(v -> acCustomer.showDropDown());

        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            allProducts.clear();
            for (ProductWithCategory pwc : products) {
                allProducts.add(pwc.product);
            }
        });

        settingViewModel.getAllSettings().observe(getViewLifecycleOwner(), settingsList -> {
            if (settingsList != null) {
                for (Setting s : settingsList) {
                    settings.put(s.getKey(), s.getValue());
                }
                updateCartUI();
            }
        });

        rgPaymentMethod.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbPosCash) {
                tilTransactionRef.setVisibility(View.GONE);
            } else {
                tilTransactionRef.setVisibility(View.VISIBLE);
            }
        });

        btnAddItem.setOnClickListener(v -> showAddItemDialog());

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(getContext(), "Cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            processSale();
        });

        return view;
    }

    private void showAddItemDialog() {
        if (allProducts.isEmpty()) {
            Toast.makeText(getContext(), "No products available", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Select Product");

        String currency = settings.getOrDefault("currency_code", "ETB");
        List<String> productNames = new ArrayList<>();
        for (Product p : allProducts) {
            productNames.add(p.getName() + " (" + currency + " " + p.getPrice() + ")");
        }

        builder.setItems(productNames.toArray(new CharSequence[0]), (dialog, which) -> {
            Product selected = allProducts.get(which);
            if (selected.getStockQuantity() <= 0) {
                Toast.makeText(getContext(), "Out of stock!", Toast.LENGTH_SHORT).show();
                return;
            }
            addToCart(selected);
        });

        builder.show();
    }

    private void addToCart(Product product) {
        boolean found = false;
        for (SaleDetail item : cartItems) {
            if (item.getProductId() == product.getId()) {
                if (item.getQuantity() < product.getStockQuantity()) {
                    item.setQuantity(item.getQuantity() + 1);
                    item.setSubtotal(item.getQuantity() * item.getUnitPrice());
                } else {
                    Toast.makeText(getContext(), "Insufficient stock", Toast.LENGTH_SHORT).show();
                }
                found = true;
                break;
            }
        }

        if (!found) {
            SaleDetail detail = new SaleDetail(0, product.getId(), 1, product.getPrice(), product.getPrice());
            cartItems.add(detail);
        }

        updateCartUI();
    }

    private void updateCartUI() {
        cartAdapter.setItems(cartItems, allProducts);
        calculateTotal();
    }

    private void calculateTotal() {
        totalAmount = 0;
        for (SaleDetail item : cartItems) {
            totalAmount += item.getSubtotal();
        }

        boolean taxEnabled = Boolean.parseBoolean(settings.getOrDefault("tax_enabled", "false"));
        double taxAmount = 0;
        if (taxEnabled) {
            double taxRate = Double.parseDouble(settings.getOrDefault("tax_rate", "0"));
            taxAmount = totalAmount * (taxRate / 100.0);
        }

        double finalTotal = totalAmount + taxAmount;
        String currency = settings.getOrDefault("currency_code", "ETB");
        tvTotal.setText(String.format(Locale.getDefault(), "%s %,.2f", currency, finalTotal));
    }

    private void processSale() {
        String selectedName = acCustomer.getText().toString().trim();
        int customerId = -1;
        
        for (Customer c : customerList) {
            if (c.getName().equalsIgnoreCase(selectedName)) {
                customerId = c.getId();
                break;
            }
        }

        if (customerId == -1) {
            Toast.makeText(getContext(), "Please select a valid customer", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedPaymentId = rgPaymentMethod.getCheckedRadioButtonId();
        RadioButton rb = getView().findViewById(selectedPaymentId);
        String paymentMethod = rb.getText().toString();
        String transactionRef = etTransactionRef.getText().toString().trim();

        if ((selectedPaymentId == R.id.rbPosTelebirr || selectedPaymentId == R.id.rbPosBank) && transactionRef.isEmpty()) {
            Toast.makeText(getContext(), "Transaction Reference is required", Toast.LENGTH_SHORT).show();
            return;
        }

        int userId = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).getInt("USER_ID", 1);
        
        boolean taxEnabled = Boolean.parseBoolean(settings.getOrDefault("tax_enabled", "false"));
        double taxRate = taxEnabled ? Double.parseDouble(settings.getOrDefault("tax_rate", "0")) : 0.0;
        double taxAmount = totalAmount * (taxRate / 100.0);

        Sale sale = new Sale(customerId, userId, System.currentTimeMillis(), totalAmount + taxAmount, taxAmount, 0.0, paymentMethod);
        if (!transactionRef.isEmpty()) {
            sale.setTransactionReference(transactionRef);
        }

        // STAFF DIRECT SALE: Set status to Delivered immediately
        sale.setOrderStatus("Delivered");
        sale.setPaymentStatus("Paid");

        saleViewModel.processSale(sale, cartItems);
        
        Toast.makeText(getContext(), "Sale completed and Delivered", Toast.LENGTH_SHORT).show();
        Navigation.findNavController(getView()).navigateUp();
    }

    @Override
    public void onQuantityChange(int position, int newQuantity) {
        if (position >= 0 && position < cartItems.size()) {
            SaleDetail item = cartItems.get(position);
            
            Product product = null;
            for (Product p : allProducts) {
                if (p.getId() == item.getProductId()) {
                    product = p;
                    break;
                }
            }

            if (product != null && newQuantity > product.getStockQuantity()) {
                Toast.makeText(getContext(), "Insufficient stock", Toast.LENGTH_SHORT).show();
                return;
            }

            item.setQuantity(newQuantity);
            item.setSubtotal(item.getUnitPrice() * newQuantity);
            updateCartUI();
        }
    }

    @Override
    public void onRemove(int position) {
        if (position >= 0 && position < cartItems.size()) {
            cartItems.remove(position);
            updateCartUI();
        }
    }
}
