package com.example.salesinventorymanagementsystem.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.model.InventoryLog;
import com.example.salesinventorymanagementsystem.repository.InventoryLogRepository;
import java.util.List;

public class InventoryLogViewModel extends AndroidViewModel {
    private InventoryLogRepository repository;
    private LiveData<List<InventoryLog>> allLogs;

    public InventoryLogViewModel(@NonNull Application application) {
        super(application);
        repository = new InventoryLogRepository(application);
        allLogs = repository.getAllLogs();
    }

    public LiveData<List<InventoryLog>> getAllLogs() {
        return allLogs;
    }

    public void insert(InventoryLog log) {
        repository.insert(log);
    }
}
