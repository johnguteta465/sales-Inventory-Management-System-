package com.example.salesinventorymanagementsystem.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.OnConflictStrategy;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.salesinventorymanagementsystem.model.Category;
import com.example.salesinventorymanagementsystem.model.Customer;
import com.example.salesinventorymanagementsystem.model.InventoryLog;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;
import com.example.salesinventorymanagementsystem.model.Setting;
import com.example.salesinventorymanagementsystem.model.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {User.class, Category.class, Product.class, Customer.class, Sale.class, SaleDetail.class, InventoryLog.class, Setting.class}, version = 15, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract CategoryDao categoryDao();
    public abstract ProductDao productDao();
    public abstract CustomerDao customerDao();
    public abstract SaleDao saleDao();
    public abstract InventoryLogDao inventoryLogDao();
    public abstract SettingDao settingDao();

    private static volatile AppDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "sales_inventory_db")
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static final RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            insertDefaultDataRaw(db);
        }

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            insertDefaultDataRaw(db);
        }
    };

    private static void insertDefaultDataRaw(SupportSQLiteDatabase db) {
        // 1. Default Users
        try (Cursor cursor = db.query("SELECT COUNT(*) FROM users")) {
            if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 0) {
                insertUser(db, "System Admin", "admin@system.com", "admin123", "0900000000", "Admin");
                insertUser(db, "Inventory Manager", "manager@system.com", "manager123", "0911000000", "Inventory Manager");
                insertUser(db, "System Cashier", "cashier@system.com", "cashier123", "0922000000", "Cashier");
            }
        } catch (Exception e) {
            Log.e("AppDatabase", "Error pre-populating users", e);
        }

        // 2. Default Categories
        try (Cursor cursor = db.query("SELECT COUNT(*) FROM categories")) {
            if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 0) {
                insertCategory(db, "Electronics", "Gadgets and devices");
                insertCategory(db, "Groceries", "Daily food items");
                insertCategory(db, "Clothing", "Apparel and accessories");
            }
        } catch (Exception e) {
            Log.e("AppDatabase", "Error pre-populating categories", e);
        }

        // 3. Default Customers
        try (Cursor cursor = db.query("SELECT COUNT(*) FROM customers")) {
            if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 0) {
                insertCustomer(db, "Guest Customer", "0000000000", "guest@example.com", "N/A");
            }
        } catch (Exception e) {
            Log.e("AppDatabase", "Error pre-populating customers", e);
        }

        // 4. Default Settings
        try (Cursor cursor = db.query("SELECT COUNT(*) FROM settings")) {
            if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 0) {
                insertSetting(db, "business_name", "Sales Inventory System");
                insertSetting(db, "currency_code", "ETB");
                insertSetting(db, "tax_enabled", "true");
                insertSetting(db, "tax_rate", "15");
            }
        } catch (Exception e) {
            Log.e("AppDatabase", "Error pre-populating settings", e);
        }
    }

    private static void insertUser(SupportSQLiteDatabase db, String name, String email, String pass, String phone, String role) {
        ContentValues cv = new ContentValues();
        cv.put("fullName", name);
        cv.put("email", email);
        cv.put("password", pass);
        cv.put("phone", phone);
        cv.put("role", role);
        db.insert("users", OnConflictStrategy.IGNORE, cv);
    }

    private static void insertCategory(SupportSQLiteDatabase db, String name, String desc) {
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("description", desc);
        db.insert("categories", OnConflictStrategy.IGNORE, cv);
    }

    private static void insertCustomer(SupportSQLiteDatabase db, String name, String phone, String email, String addr) {
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("phone", phone);
        cv.put("email", email);
        cv.put("address", addr);
        db.insert("customers", OnConflictStrategy.IGNORE, cv);
    }

    private static void insertSetting(SupportSQLiteDatabase db, String key, String val) {
        ContentValues cv = new ContentValues();
        cv.put("key", key);
        cv.put("value", val);
        db.insert("settings", OnConflictStrategy.IGNORE, cv);
    }
}
