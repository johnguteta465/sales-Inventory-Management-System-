package com.example.salesinventorymanagementsystem.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.salesinventorymanagementsystem.model.Setting;

import java.util.List;

@Dao
public interface SettingDao {
    @Query("SELECT * FROM settings")
    LiveData<List<Setting>> getAllSettings();

    @Query("SELECT * FROM settings")
    List<Setting> getAllSettingsSync();

    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    Setting getSettingSync(String key);

    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    LiveData<Setting> getSetting(String key);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Setting setting);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Setting> settings);
}
