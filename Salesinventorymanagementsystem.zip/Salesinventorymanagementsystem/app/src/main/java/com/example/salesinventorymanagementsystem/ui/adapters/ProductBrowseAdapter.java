package com.example.salesinventorymanagementsystem.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.google.android.material.button.MaterialButton;

import java.util.Locale;

public class ProductBrowseAdapter extends ListAdapter<ProductWithCategory, ProductBrowseAdapter.ProductViewHolder> {

    private final OnProductClickListener listener;

    public interface OnProductClickListener {
        void onProductClick(Product product);
        void onAddToCartClick(Product product);
    }

    public ProductBrowseAdapter(OnProductClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<ProductWithCategory> DIFF_CALLBACK = new DiffUtil.ItemCallback<ProductWithCategory>() {
        @Override
        public boolean areItemsTheSame(@NonNull ProductWithCategory oldItem, @NonNull ProductWithCategory newItem) {
            return oldItem.product.getId() == newItem.product.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull ProductWithCategory oldItem, @NonNull ProductWithCategory newItem) {
            return oldItem.product.getName().equals(newItem.product.getName()) &&
                    oldItem.product.getPrice() == newItem.product.getPrice() &&
                    oldItem.product.getStockQuantity() == newItem.product.getStockQuantity() &&
                    (oldItem.category != null && newItem.category != null && oldItem.category.getName().equals(newItem.category.getName()));
        }
    };

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_browse, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        ProductWithCategory current = getItem(position);
        Product product = current.product;

        holder.tvName.setText(product.getName());
        holder.tvPrice.setText(String.format(Locale.getDefault(), "$%.2f", product.getPrice()));
        holder.tvStock.setText(String.format(Locale.getDefault(), "In Stock: %d", product.getStockQuantity()));

        if (current.category != null) {
            holder.tvCategory.setText(current.category.getName());
        } else {
            holder.tvCategory.setText("Uncategorized");
        }

        if (product.getImageUri() != null && !product.getImageUri().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                    .load(product.getImageUri())
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .into(holder.ivProduct);
        } else {
            holder.ivProduct.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        holder.itemView.setOnClickListener(v -> listener.onProductClick(product));
        
        if (product.getStockQuantity() > 0) {
            holder.btnAddToCart.setEnabled(true);
            holder.btnAddToCart.setAlpha(1.0f);
            holder.btnAddToCart.setOnClickListener(v -> listener.onAddToCartClick(product));
        } else {
            holder.btnAddToCart.setEnabled(false);
            holder.btnAddToCart.setAlpha(0.5f);
            holder.tvStock.setText("Out of Stock");
        }
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvName, tvPrice, tvCategory, tvStock;
        private final ImageView ivProduct;
        private final MaterialButton btnAddToCart;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvProductName);
            tvPrice = itemView.findViewById(R.id.tvProductPrice);
            tvCategory = itemView.findViewById(R.id.tvProductCategory);
            tvStock = itemView.findViewById(R.id.tvProductStock);
            ivProduct = itemView.findViewById(R.id.ivProductImage);
            btnAddToCart = itemView.findViewById(R.id.btnAddToCart);
        }
    }
}
