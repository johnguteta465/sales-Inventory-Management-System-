package com.example.salesinventorymanagementsystem.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;

import java.util.List;

@Dao
public interface ProductDao {
    @Insert
    void insert(Product product);

    @Update
    void update(Product product);

    @Delete
    void delete(Product product);

    @Query("SELECT * FROM products ORDER BY name ASC")
    LiveData<List<Product>> getAllProducts();

    @Transaction
    @Query("SELECT * FROM products ORDER BY name ASC")
    LiveData<List<ProductWithCategory>> getAllProductsWithCategory();

    @Query("SELECT * FROM products WHERE id = :productId LIMIT 1")
    Product getProductById(int productId);

    @Query("SELECT * FROM products WHERE categoryId = :categoryId")
    LiveData<List<Product>> getProductsByCategory(int categoryId);

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    Product getProductByBarcode(String barcode);

    @Query("SELECT * FROM products WHERE stockQuantity <= (SELECT CAST(value AS INTEGER) FROM settings WHERE `key` = 'low_stock_limit')")
    LiveData<List<Product>> getLowStockProducts();

    @Query("UPDATE products SET stockQuantity = stockQuantity + :change WHERE id = :productId")
    void updateStock(int productId, int change);
}
