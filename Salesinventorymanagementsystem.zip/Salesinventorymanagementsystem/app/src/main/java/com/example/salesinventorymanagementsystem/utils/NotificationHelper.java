package com.example.salesinventorymanagementsystem.utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.example.salesinventorymanagementsystem.R;

public class NotificationHelper {
    private static final String CHANNEL_ID = "inventory_alerts";
    private static final String CHANNEL_NAME = "Inventory Alerts";

    public static void showLowStockNotification(Context context, String productName, int currentStock) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Low Stock Alert")
                .setContentText("Product '" + productName + "' is low on stock: " + currentStock + " left.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        notificationManager.notify(productName.hashCode(), builder.build());
    }
}
