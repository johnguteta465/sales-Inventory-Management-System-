package com.example.salesinventorymanagementsystem.ui.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.User;
import com.example.salesinventorymanagementsystem.viewmodel.UserViewModel;
import com.google.android.material.textfield.TextInputEditText;

public class ProfileFragment extends Fragment {

    private TextInputEditText etName, etEmail, etPhone, etPassword;
    private Button btnUpdate, btnLogout;
    private UserViewModel userViewModel;
    private User currentUser;
    private int currentUserId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        SharedPreferences prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        currentUserId = prefs.getInt("USER_ID", -1);

        etName = view.findViewById(R.id.etProfileName);
        etEmail = view.findViewById(R.id.etProfileEmail);
        etPhone = view.findViewById(R.id.etProfilePhone);
        etPassword = view.findViewById(R.id.etProfilePassword);
        btnUpdate = view.findViewById(R.id.btnUpdateProfile);
        btnLogout = view.findViewById(R.id.btnLogout);

        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        if (currentUserId != -1) {
            new Thread(() -> {
                currentUser = userViewModel.getUserById(currentUserId);
                if (currentUser != null && getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        etName.setText(currentUser.getFullName());
                        etEmail.setText(currentUser.getEmail());
                        etPhone.setText(currentUser.getPhone());
                        etPassword.setText(currentUser.getPassword());
                    });
                }
            }).start();
        }

        btnUpdate.setOnClickListener(v -> {
            if (currentUser != null) {
                currentUser.setFullName(etName.getText().toString().trim());
                currentUser.setEmail(etEmail.getText().toString().trim());
                currentUser.setPhone(etPhone.getText().toString().trim());
                currentUser.setPassword(etPassword.getText().toString().trim());

                if (currentUser.getFullName().isEmpty() || currentUser.getEmail().isEmpty()) {
                    Toast.makeText(getContext(), "Name and Email cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                userViewModel.update(currentUser);
                Toast.makeText(getContext(), "Profile updated successfully!", Toast.LENGTH_SHORT).show();
                
                // Update session
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("USER_NAME", currentUser.getFullName());
                editor.apply();
            }
        });

        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();
            if (getActivity() != null) {
                getActivity().finish();
            }
        });

        return view;
    }
}
