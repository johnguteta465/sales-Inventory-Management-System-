package com.example.salesinventorymanagementsystem.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "sale_details",
        foreignKeys = {
                @ForeignKey(entity = Sale.class,
                        parentColumns = "id",
                        childColumns = "sale_id",
                        onDelete = ForeignKey.CASCADE),
                @ForeignKey(entity = Product.class,
                        parentColumns = "id",
                        childColumns = "product_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {@Index("sale_id"), @Index("product_id")})
public class SaleDetail {
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    @ColumnInfo(name = "sale_id")
    private int saleId;
    
    @ColumnInfo(name = "product_id")
    private int productId;
    
    private int quantity;
    
    @ColumnInfo(name = "unit_price")
    private double unitPrice;

    private double subtotal;

    public SaleDetail(int saleId, int productId, int quantity, double unitPrice, double subtotal) {
        this.saleId = saleId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.subtotal = subtotal;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getSaleId() { return saleId; }
    public void setSaleId(int saleId) { this.saleId = saleId; }
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
}
