package com.example.salesinventorymanagementsystem.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Sale;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyOrdersAdapter extends ListAdapter<Sale, MyOrdersAdapter.OrderViewHolder> {

    private final OnOrderClickListener listener;

    public interface OnOrderClickListener {
        void onOrderClick(Sale sale);
    }

    public MyOrdersAdapter(OnOrderClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<Sale> DIFF_CALLBACK = new DiffUtil.ItemCallback<Sale>() {
        @Override
        public boolean areItemsTheSame(@NonNull Sale oldItem, @NonNull Sale newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Sale oldItem, @NonNull Sale newItem) {
            return oldItem.getOrderStatus().equals(newItem.getOrderStatus()) &&
                    oldItem.getTotalAmount() == newItem.getTotalAmount() &&
                    oldItem.getPaymentMethod().equals(newItem.getPaymentMethod());
        }
    };

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Sale sale = getItem(position);
        
        holder.tvOrderId.setText(String.format(Locale.getDefault(), "Order #%04d", sale.getId()));
        holder.tvOrderTotal.setText(String.format(Locale.getDefault(), "$%.2f", sale.getTotalAmount()));
        holder.tvPaymentMethod.setText(sale.getPaymentMethod());
        
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        holder.tvOrderDate.setText(sdf.format(new Date(sale.getTimestamp())));
        
        String status = sale.getOrderStatus();
        holder.tvOrderStatus.setText(status);
        
        // Color coding for status
        int colorRes = R.color.text_secondary;
        if ("Pending".equalsIgnoreCase(status)) colorRes = android.R.color.holo_orange_dark;
        else if ("Shipped".equalsIgnoreCase(status)) colorRes = android.R.color.holo_blue_dark;
        else if ("Delivered".equalsIgnoreCase(status)) colorRes = android.R.color.holo_green_dark;
        
        holder.tvOrderStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), colorRes));
        
        holder.itemView.setOnClickListener(v -> listener.onOrderClick(sale));
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderDate, tvOrderTotal, tvOrderStatus, tvPaymentMethod;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvMyOrderId);
            tvOrderDate = itemView.findViewById(R.id.tvMyOrderDate);
            tvOrderTotal = itemView.findViewById(R.id.tvMyOrderTotal);
            tvOrderStatus = itemView.findViewById(R.id.tvMyOrderStatus);
            tvPaymentMethod = itemView.findViewById(R.id.tvMyOrderPaymentMethod);
        }
    }
}
