package com.example.salesinventorymanagementsystem.ui.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;
import com.example.salesinventorymanagementsystem.ui.adapters.SaleAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SettingViewModel;
import com.example.salesinventorymanagementsystem.utils.PdfHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import java.util.Map;

public class SaleListFragment extends Fragment implements SaleAdapter.OnSaleClickListener {

    private SaleViewModel saleViewModel;
    private SettingViewModel settingViewModel;
    private SaleAdapter adapter;
    private String userRole;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sale_list, container, false);

        SharedPreferences prefs = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        userRole = prefs.getString("USER_ROLE", "Customer");

        RecyclerView recyclerView = view.findViewById(R.id.rvSales);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new SaleAdapter(this);
        recyclerView.setAdapter(adapter);

        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);
        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);
        
        saleViewModel.getAllSales().observe(getViewLifecycleOwner(), sales -> {
            adapter.submitList(sales);
        });

        FloatingActionButton fab = view.findViewById(R.id.fabAddSale);
        if ("Customer".equalsIgnoreCase(userRole)) {
            fab.setVisibility(View.GONE);
        } else {
            fab.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_nav_sales_to_nav_new_sale));
        }

        return view;
    }

    @Override
    public void onPrintReceipt(Sale sale) {
        new Thread(() -> {
            List<SaleDetail> details = saleViewModel.getDetailsForSaleSync(sale.getId());
            Map<String, String> settings = settingViewModel.getAllSettingsAsMapSync();
            
            if (details != null && isAdded()) {
                getActivity().runOnUiThread(() -> {
                    PdfHelper.generateReceipt(getContext(), sale, details, settings);
                });
            }
        }).start();
    }

    @Override
    public void onSaleClick(Sale sale) {
        if ("Customer".equalsIgnoreCase(userRole)) {
            // Customers can only view details
            Bundle args = new Bundle();
            args.putInt("saleId", sale.getId());
            Navigation.findNavController(requireView()).navigate(R.id.nav_order_details, args);
            return;
        }

        // Staff (Admin, Cashier, Inventory Manager) can update status
        String[] options = {"View Details", "Update Status to Shipped", "Update Status to Delivered", "Print Receipt"};
        
        new AlertDialog.Builder(getContext())
                .setTitle("Order INV-" + sale.getId())
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: // View Details
                            Bundle args = new Bundle();
                            args.putInt("saleId", sale.getId());
                            Navigation.findNavController(requireView()).navigate(R.id.nav_order_details, args);
                            break;
                        case 1: // Shipped
                            updateOrderStatus(sale, "Shipped");
                            break;
                        case 2: // Delivered
                            updateOrderStatus(sale, "Delivered");
                            break;
                        case 3: // Print Receipt
                            onPrintReceipt(sale);
                            break;
                    }
                })
                .show();
    }

    private void updateOrderStatus(Sale sale, String status) {
        saleViewModel.updateStatus(sale.getId(), status);
        Toast.makeText(getContext(), "Order status updated to " + status, Toast.LENGTH_SHORT).show();
    }
}
