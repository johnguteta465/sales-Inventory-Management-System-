package com.example.salesinventorymanagementsystem.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;

import com.example.salesinventorymanagementsystem.MainActivity;
import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.api.RetrofitClient;
import com.example.salesinventorymanagementsystem.model.Customer;
import com.example.salesinventorymanagementsystem.model.User;
import com.example.salesinventorymanagementsystem.viewmodel.CustomerViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SettingViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.UserViewModel;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etFullName, etEmail, etPhone, etPassword, etConfirmPassword;
    private UserViewModel userViewModel;
    private CustomerViewModel customerViewModel;
    private SettingViewModel settingViewModel;
    private int minPasswordLength = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        applySavedTheme();
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        View mainView = findViewById(R.id.register_root);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etUsername);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvLogin = findViewById(R.id.tvLogin);

        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);
        
        settingViewModel.getSetting("min_password_length").observe(this, setting -> {
            if (setting != null) {
                try {
                    minPasswordLength = Integer.parseInt(setting.getValue());
                } catch (NumberFormatException ignored) {}
            }
        });

        btnRegister.setOnClickListener(v -> {
            String fullName = etFullName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();
            String role = "Customer";

            if (fullName.isEmpty() || email.isEmpty() || password.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Strong Password Validation
            int requiredLength = Math.max(8, minPasswordLength);
            if (password.length() < requiredLength || 
                !password.matches(".*[A-Z].*") || 
                !password.matches(".*[0-9].*") || 
                !password.matches(".*[@#$%^&+=!].*")) {
                Toast.makeText(this, "Password must be at least " + requiredLength + " chars with a Capital letter, Number, and Special Char (@#$%^&+=!)", Toast.LENGTH_LONG).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // OFFLINE SUPPORT: Save user locally immediately
            saveUserLocally(fullName, email, password, phone, role);

            // SYNC ATTEMPT: Send data to PHP -> SSMS
            RetrofitClient.getApiService().register(email, password, role, fullName).enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        Log.d("SYNC_DEBUG", "Successfully synced to SSMS!");
                    } else {
                        Log.e("SYNC_DEBUG", "Server returned error: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Log.e("SYNC_DEBUG", "Sync Failed! Check Firewall/Network: " + t.getMessage());
                }
            });
        });

        tvLogin.setOnClickListener(v -> finish());
    }

    private void saveUserLocally(String fullName, String email, String password, String phone, String role) {
        new Thread(() -> {
            User user = new User(fullName, email, password, phone, role);
            long id = userViewModel.insert(user);
            customerViewModel.insert(new Customer(fullName, phone, email, ""));
            
            runOnUiThread(() -> {
                if (id != -1) {
                    SharedPreferences prefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("USER_ID", (int) id);
                    editor.putString("USER_NAME", fullName);
                    editor.putString("USER_ROLE", role);
                    editor.apply();

                    Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            });
        }).start();
    }

    private void applySavedTheme() {
        SharedPreferences sharedPreferences = getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE);
        boolean isDarkMode = sharedPreferences.getBoolean("isDarkMode", false);
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}
