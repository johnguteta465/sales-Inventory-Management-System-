package com.example.salesinventorymanagementsystem.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.salesinventorymanagementsystem.model.Customer;

import java.util.List;

@Dao
public interface CustomerDao {
    @Insert
    void insert(Customer customer);

    @Update
    void update(Customer customer);

    @Delete
    void delete(Customer customer);

    @Query("SELECT * FROM customers ORDER BY name ASC")
    LiveData<List<Customer>> getAllCustomers();

    @Query("SELECT * FROM customers WHERE name LIKE :query OR phone LIKE :query")
    LiveData<List<Customer>> searchCustomers(String query);

    @Query("SELECT COUNT(*) FROM customers")
    int getCustomerCount();
}
