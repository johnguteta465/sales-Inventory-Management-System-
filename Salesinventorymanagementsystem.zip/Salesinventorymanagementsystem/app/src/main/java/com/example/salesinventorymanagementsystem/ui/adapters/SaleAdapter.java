package com.example.salesinventorymanagementsystem.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SaleAdapter extends ListAdapter<Sale, SaleAdapter.SaleViewHolder> {

    private final OnSaleClickListener listener;

    public interface OnSaleClickListener {
        void onPrintReceipt(Sale sale);
        void onSaleClick(Sale sale);
    }

    public SaleAdapter(OnSaleClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<Sale> DIFF_CALLBACK = new DiffUtil.ItemCallback<Sale>() {
        @Override
        public boolean areItemsTheSame(@NonNull Sale oldItem, @NonNull Sale newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Sale oldItem, @NonNull Sale newItem) {
            return oldItem.getTotalAmount() == newItem.getTotalAmount() &&
                    oldItem.getTimestamp() == newItem.getTimestamp() &&
                    (oldItem.getOrderStatus() != null && oldItem.getOrderStatus().equals(newItem.getOrderStatus()));
        }
    };

    @NonNull
    @Override
    public SaleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sale, parent, false);
        return new SaleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SaleViewHolder holder, int position) {
        Sale current = getItem(position);
        
        holder.tvId.setText(String.format(Locale.getDefault(), "INV-%04d", current.getId()));
        
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.getDefault());
        holder.tvDate.setText(sdf.format(new Date(current.getTimestamp())));
        
        holder.tvTotal.setText(String.format(Locale.getDefault(), "$%.2f", current.getTotalAmount()));
        
        String status = current.getOrderStatus() != null ? current.getOrderStatus() : "Pending";
        holder.tvStatus.setText(status);

        // Styling status based on value
        if ("Delivered".equalsIgnoreCase(status)) {
            holder.statusCard.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.holo_green_light));
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.white));
        } else if ("Shipped".equalsIgnoreCase(status)) {
            holder.statusCard.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.holo_blue_light));
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.white));
        } else {
            holder.statusCard.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.darker_gray));
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.white));
        }

        if (holder.btnPrint != null) {
            holder.btnPrint.setVisibility(View.VISIBLE);
            holder.btnPrint.setOnClickListener(v -> listener.onPrintReceipt(current));
        }

        holder.itemView.setOnClickListener(v -> listener.onSaleClick(current));
    }

    static class SaleViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvId, tvDate, tvTotal, tvStatus;
        private final ImageButton btnPrint;
        private final MaterialCardView statusCard;

        public SaleViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvSaleId);
            tvDate = itemView.findViewById(R.id.tvSaleDate);
            tvTotal = itemView.findViewById(R.id.tvSaleTotalAmount);
            tvStatus = itemView.findViewById(R.id.tvSaleStatus);
            btnPrint = itemView.findViewById(R.id.btnPrintReceipt);
            statusCard = (MaterialCardView) tvStatus.getParent();
        }
    }
}
