package com.example.salesinventorymanagementsystem.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "sales")
public class Sale {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;
    
    @SerializedName("total_amount")
    @ColumnInfo(name = "total_amount")
    private double totalAmount;
    
    @SerializedName("payment_status")
    @ColumnInfo(name = "payment_status")
    private String paymentStatus;
    
    @SerializedName("order_status")
    @ColumnInfo(name = "order_status")
    private String orderStatus; // Pending, Shipped, Delivered
    
    @ColumnInfo(name = "timestamp")
    private long timestamp;
    
    @ColumnInfo(name = "customer_id")
    private int customerId;
    
    @ColumnInfo(name = "user_id")
    private int userId;
    
    @ColumnInfo(name = "tax")
    private double tax;
    
    @ColumnInfo(name = "discount")
    private double discount;
    
    @ColumnInfo(name = "payment_method")
    private String paymentMethod;
    
    @SerializedName("transaction_reference")
    @ColumnInfo(name = "transaction_reference")
    private String transactionReference;

    public Sale() {
        this.orderStatus = "Pending";
    }

    public Sale(int customerId, int userId, long timestamp, double totalAmount, double tax, double discount, String paymentMethod) {
        this.customerId = customerId;
        this.userId = userId;
        this.timestamp = timestamp;
        this.totalAmount = totalAmount;
        this.tax = tax;
        this.discount = discount;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = "Paid";
        this.orderStatus = "Pending";
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public String getOrderStatus() { return orderStatus; }
    public void setOrderStatus(String orderStatus) { this.orderStatus = orderStatus; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public double getTax() { return tax; }
    public void setTax(double tax) { this.tax = tax; }
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public String getTransactionReference() { return transactionReference; }
    public void setTransactionReference(String transactionReference) { this.transactionReference = transactionReference; }
}
