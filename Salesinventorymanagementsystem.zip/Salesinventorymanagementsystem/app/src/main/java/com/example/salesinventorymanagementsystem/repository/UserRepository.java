package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.UserDao;
import com.example.salesinventorymanagementsystem.model.User;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class UserRepository {
    private UserDao userDao;
    private LiveData<List<User>> allUsers;

    public UserRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        userDao = db.userDao();
        allUsers = userDao.getAllUsers();
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    public long insert(User user) {
        Future<Long> future = AppDatabase.databaseWriteExecutor.submit(() -> userDao.insert(user));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public void update(User user) {
        AppDatabase.databaseWriteExecutor.execute(() -> userDao.update(user));
    }

    public void delete(User user) {
        AppDatabase.databaseWriteExecutor.execute(() -> userDao.delete(user));
    }

    public User login(String email, String password) {
        Future<User> future = AppDatabase.databaseWriteExecutor.submit(() -> userDao.login(email, password));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public User getUserById(int id) {
        Future<User> future = AppDatabase.databaseWriteExecutor.submit(() -> userDao.getUserById(id));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getUserCount() {
        Future<Integer> future = AppDatabase.databaseWriteExecutor.submit(() -> userDao.getUserCount());
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
