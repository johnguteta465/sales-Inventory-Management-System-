package com.example.salesinventorymanagementsystem.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;
import com.example.salesinventorymanagementsystem.ui.adapters.CartAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.SaleViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderDetailsFragment extends Fragment {

    private SaleViewModel saleViewModel;
    private ProductViewModel productViewModel;
    private CartAdapter adapter;
    private int saleId;
    
    private List<Product> allProducts = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order_details, container, false);

        if (getArguments() != null) {
            saleId = getArguments().getInt("saleId");
        }

        TextView tvOrderId = view.findViewById(R.id.tvDetailsOrderId);
        RecyclerView rvItems = view.findViewById(R.id.rvOrderDetailsItems);
        
        tvOrderId.setText(String.format(Locale.getDefault(), "Order #%04d", saleId));
        
        rvItems.setLayoutManager(new LinearLayoutManager(getContext()));
        // Use CartAdapter in read-only mode (no listeners)
        adapter = new CartAdapter(null);
        rvItems.setAdapter(adapter);

        saleViewModel = new ViewModelProvider(this).get(SaleViewModel.class);
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);

        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            allProducts.clear();
            for (ProductWithCategory pwc : products) {
                allProducts.add(pwc.product);
            }
            loadDetails();
        });

        return view;
    }

    private void loadDetails() {
        saleViewModel.getDetailsForSale(saleId).observe(getViewLifecycleOwner(), details -> {
            if (details != null && !allProducts.isEmpty()) {
                adapter.setItems(details, allProducts);
            }
        });
    }
}
