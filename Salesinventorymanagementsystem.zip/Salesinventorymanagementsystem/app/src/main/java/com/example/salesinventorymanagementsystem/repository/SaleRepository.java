package com.example.salesinventorymanagementsystem.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.salesinventorymanagementsystem.database.AppDatabase;
import com.example.salesinventorymanagementsystem.database.SaleDao;
import com.example.salesinventorymanagementsystem.database.ProductDao;
import com.example.salesinventorymanagementsystem.database.InventoryLogDao;
import com.example.salesinventorymanagementsystem.model.InventoryLog;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.Sale;
import com.example.salesinventorymanagementsystem.model.SaleDetail;
import com.example.salesinventorymanagementsystem.utils.NotificationHelper;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class SaleRepository {
    private SaleDao saleDao;
    private ProductDao productDao;
    private InventoryLogDao inventoryLogDao;
    private LiveData<List<Sale>> allSales;
    private Application application;

    public SaleRepository(Application application) {
        this.application = application;
        AppDatabase db = AppDatabase.getDatabase(application);
        saleDao = db.saleDao();
        productDao = db.productDao();
        inventoryLogDao = db.inventoryLogDao();
        allSales = saleDao.getAllSales();
    }

    public LiveData<List<Sale>> getAllSales() {
        return allSales;
    }

    public LiveData<List<Sale>> getSalesByCustomer(int customerId) {
        return saleDao.getSalesByCustomer(customerId);
    }

    public void processSale(Sale sale, List<SaleDetail> details) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            long saleId = saleDao.insert(sale);
            for (SaleDetail detail : details) {
                detail.setSaleId((int) saleId);
                productDao.updateStock(detail.getProductId(), -detail.getQuantity());
                
                inventoryLogDao.insert(new InventoryLog(detail.getProductId(), -detail.getQuantity(), "Sale #" + saleId, System.currentTimeMillis()));
                
                Product product = productDao.getProductById(detail.getProductId());
                if (product != null && product.getStockQuantity() <= 5) {
                    NotificationHelper.showLowStockNotification(application, product.getName(), product.getStockQuantity());
                }
            }
            saleDao.insertDetails(details);
        });
    }

    public void updateStatus(int saleId, String status) {
        AppDatabase.databaseWriteExecutor.execute(() -> saleDao.updateStatus(saleId, status));
    }

    public LiveData<List<SaleDetail>> getDetailsForSale(int saleId) {
        return saleDao.getDetailsForSale(saleId);
    }

    public List<SaleDetail> getDetailsForSaleSync(int saleId) {
        Future<List<SaleDetail>> future = AppDatabase.databaseWriteExecutor.submit(() -> saleDao.getDetailsForSaleSync(saleId));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public LiveData<Double> getTotalRevenue(long start, long end) {
        return saleDao.getTotalRevenue(start, end);
    }

    public double getRevenueToday(long startDate, int userId) {
        Future<Double> future = AppDatabase.databaseWriteExecutor.submit(() -> saleDao.getRevenueToday(startDate, userId));
        try {
            Double result = future.get();
            return result != null ? result : 0.0;
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return 0.0;
        }
    }

    public int getTransactionCountToday(long startDate, int userId) {
        Future<Integer> future = AppDatabase.databaseWriteExecutor.submit(() -> saleDao.getTransactionCountToday(startDate, userId));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getItemsSoldToday(long startDate, int userId) {
        Future<Integer> future = AppDatabase.databaseWriteExecutor.submit(() -> saleDao.getItemsSoldToday(startDate, userId));
        try {
            return future.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
