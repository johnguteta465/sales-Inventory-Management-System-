package com.example.salesinventorymanagementsystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.salesinventorymanagementsystem.ui.LoginActivity;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private DrawerLayout drawer;
    private NavController navController;
    private String userRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply saved theme preference (Light/Dark)
        applySavedTheme();
        
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userRole = getIntent().getStringExtra("USER_ROLE");
        if (userRole == null) userRole = "Cashier";

        drawer = findViewById(R.id.drawer_layout);
        AppBarLayout appBarLayout = findViewById(R.id.app_bar_layout);

        // SYSTEM INSET FIX: Dynamically adds padding to prevent top overlap with status bar
        ViewCompat.setOnApplyWindowInsetsListener(drawer, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            if (appBarLayout != null) {
                appBarLayout.setPadding(0, systemBars.top, 0, 0);
            }
            return WindowInsetsCompat.CONSUMED;
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setTitle("");

        NavigationView navigationView = findViewById(R.id.nav_view);
        setupMenuVisibility(navigationView.getMenu());

        TextView tvSubtitle = findViewById(R.id.tvToolbarSubtitle);
        if (tvSubtitle != null) {
            tvSubtitle.setText(userRole);
        }

        // Sidebar Navigation Configuration
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_dashboard, R.id.nav_new_sale, R.id.nav_products, R.id.nav_sales,
                R.id.nav_browse_products, R.id.nav_my_orders, R.id.nav_cart, R.id.nav_users,
                R.id.nav_categories, R.id.nav_inventory, R.id.nav_settings, R.id.nav_customers)
                .setOpenableLayout(drawer)
                .build();

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        navController = Objects.requireNonNull(navHostFragment).getNavController();
        
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        navigationView.setNavigationItemSelectedListener(this);

        // Sync Toolbar title with current screen
        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            TextView tvTitle = findViewById(R.id.tvCustomToolbarTitle);
            if (tvTitle != null) {
                tvTitle.setText(destination.getLabel());
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (drawer != null && drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                    setEnabled(true);
                }
            }
        });

        View headerView = navigationView.getHeaderView(0);
        if (headerView != null) {
            TextView tvHeaderUser = headerView.findViewById(R.id.tvHeaderUser);
            TextView tvHeaderRole = headerView.findViewById(R.id.tvHeaderRole);
            String username = getIntent().getStringExtra("USER_NAME");
            if (username != null && tvHeaderUser != null) tvHeaderUser.setText(username);
            if (tvHeaderRole != null) tvHeaderRole.setText(userRole);
        }
    }

    private void applySavedTheme() {
        SharedPreferences prefs = getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE);
        boolean isDarkMode = prefs.getBoolean("isDarkMode", false);
        AppCompatDelegate.setDefaultNightMode(isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }

    private void setupMenuVisibility(Menu menu) {
        menu.setGroupVisible(R.id.group_admin, userRole.equalsIgnoreCase("Admin"));
        menu.setGroupVisible(R.id.group_cashier, userRole.equalsIgnoreCase("Cashier"));
        menu.setGroupVisible(R.id.group_inventory, userRole.equalsIgnoreCase("Inventory Manager"));
        menu.setGroupVisible(R.id.group_customer, userRole.equalsIgnoreCase("Customer"));
        
        MenuItem customerItem = menu.findItem(R.id.nav_customers);
        if (customerItem != null) {
            customerItem.setVisible(!userRole.equalsIgnoreCase("Customer"));
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, mAppBarConfiguration) || super.onSupportNavigateUp();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_logout) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        boolean handled = NavigationUI.onNavDestinationSelected(item, navController);
        if (handled) drawer.closeDrawer(GravityCompat.START);
        return handled;
    }
}
