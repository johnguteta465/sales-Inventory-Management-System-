package com.example.salesinventorymanagementsystem.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.ui.adapters.CategoryBrowseAdapter;
import com.example.salesinventorymanagementsystem.ui.adapters.ProductBrowseAdapter;
import com.example.salesinventorymanagementsystem.viewmodel.CartViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.CategoryViewModel;
import com.example.salesinventorymanagementsystem.viewmodel.ProductViewModel;

public class BrowseProductsFragment extends Fragment {

    private ProductViewModel productViewModel;
    private CategoryViewModel categoryViewModel;
    private CartViewModel cartViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_browse_products, container, false);

        RecyclerView rvCategories = view.findViewById(R.id.rvBrowseCategories);
        RecyclerView rvProducts = view.findViewById(R.id.rvBrowseProducts);
        View btnCart = view.findViewById(R.id.btnCart);

        rvCategories.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        rvProducts.setLayoutManager(new GridLayoutManager(getContext(), 2));

        CategoryBrowseAdapter categoryAdapter = new CategoryBrowseAdapter();
        rvCategories.setAdapter(categoryAdapter);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        categoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
        cartViewModel = new ViewModelProvider(requireActivity()).get(CartViewModel.class);

        ProductBrowseAdapter productAdapter = new ProductBrowseAdapter(new ProductBrowseAdapter.OnProductClickListener() {
            @Override
            public void onProductClick(Product product) {
                // Handle product click
            }

            @Override
            public void onAddToCartClick(Product product) {
                cartViewModel.addToCart(product);
                Toast.makeText(getContext(), "Added " + product.getName() + " to cart", Toast.LENGTH_SHORT).show();
            }
        });
        rvProducts.setAdapter(productAdapter);

        categoryViewModel.getAllCategories().observe(getViewLifecycleOwner(), categories -> {
            categoryAdapter.submitList(categories);
        });

        productViewModel.getAllProductsWithCategory().observe(getViewLifecycleOwner(), products -> {
            productAdapter.submitList(products);
        });

        btnCart.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.nav_cart);
        });

        return view;
    }
}
