package com.example.salesinventorymanagementsystem.ui.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.InventoryLog;
import com.example.salesinventorymanagementsystem.model.Product;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class InventoryLogAdapter extends ListAdapter<InventoryLog, InventoryLogAdapter.LogViewHolder> {

    private List<Product> productList;

    public InventoryLogAdapter() {
        super(DIFF_CALLBACK);
    }

    public void setProducts(List<Product> products) {
        this.productList = products;
        notifyDataSetChanged();
    }

    private static final DiffUtil.ItemCallback<InventoryLog> DIFF_CALLBACK = new DiffUtil.ItemCallback<InventoryLog>() {
        @Override
        public boolean areItemsTheSame(@NonNull InventoryLog oldItem, @NonNull InventoryLog newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull InventoryLog oldItem, @NonNull InventoryLog newItem) {
            return oldItem.getChangeAmount() == newItem.getChangeAmount() &&
                    oldItem.getTimestamp() == newItem.getTimestamp();
        }
    };

    @NonNull
    @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory_log, parent, false);
        return new LogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LogViewHolder holder, int position) {
        InventoryLog log = getItem(position);
        
        String productName = "Product ID: " + log.getProductId();
        if (productList != null) {
            for (Product p : productList) {
                if (p.getId() == log.getProductId()) {
                    productName = p.getName();
                    break;
                }
            }
        }
        
        holder.tvProductName.setText(productName);
        holder.tvReason.setText("Reason: " + log.getReason());
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        holder.tvDate.setText(sdf.format(new Date(log.getTimestamp())));
        
        int amount = log.getChangeAmount();
        holder.tvAmount.setText((amount > 0 ? "+" : "") + amount);
        holder.tvAmount.setTextColor(amount > 0 ? Color.GREEN : Color.RED);
    }

    static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView tvProductName, tvReason, tvDate, tvAmount;

        public LogViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.tvLogProductName);
            tvReason = itemView.findViewById(R.id.tvLogReason);
            tvDate = itemView.findViewById(R.id.tvLogDate);
            tvAmount = itemView.findViewById(R.id.tvLogAmount);
        }
    }
}
