package com.example.salesinventorymanagementsystem.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.salesinventorymanagementsystem.R;
import com.example.salesinventorymanagementsystem.model.Product;
import com.example.salesinventorymanagementsystem.model.ProductWithCategory;

import java.util.Locale;

public class ProductAdapter extends ListAdapter<ProductWithCategory, ProductAdapter.ProductViewHolder> {

    private final OnProductClickListener listener;
    private final String userRole;

    public interface OnProductClickListener {
        void onEditClick(Product product);
        void onDeleteClick(Product product);
    }

    public ProductAdapter(OnProductClickListener listener, String userRole) {
        super(DIFF_CALLBACK);
        this.listener = listener;
        this.userRole = userRole;
    }

    private static final DiffUtil.ItemCallback<ProductWithCategory> DIFF_CALLBACK = new DiffUtil.ItemCallback<ProductWithCategory>() {
        @Override
        public boolean areItemsTheSame(@NonNull ProductWithCategory oldItem, @NonNull ProductWithCategory newItem) {
            return oldItem.product.getId() == newItem.product.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull ProductWithCategory oldItem, @NonNull ProductWithCategory newItem) {
            return oldItem.product.getName().equals(newItem.product.getName()) &&
                    oldItem.product.getPrice() == newItem.product.getPrice() &&
                    oldItem.product.getStockQuantity() == newItem.product.getStockQuantity() &&
                    (oldItem.category != null && newItem.category != null && oldItem.category.getName().equals(newItem.category.getName()));
        }
    };

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        ProductWithCategory current = getItem(position);
        Product product = current.product;
        
        holder.tvName.setText(product.getName());
        holder.tvPrice.setText(String.format(Locale.getDefault(), "$%.2f", product.getPrice()));
        holder.tvStock.setText(String.format(Locale.getDefault(), "Stock: %d", product.getStockQuantity()));
        
        if (current.category != null) {
            holder.tvCategory.setText(current.category.getName());
        } else {
            holder.tvCategory.setText("Uncategorized");
        }

        if (product.getImageUri() != null && !product.getImageUri().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                    .load(product.getImageUri())
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .into(holder.ivProduct);
        } else {
            holder.ivProduct.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        // ROLE RESTRICTION: Only Admin can Edit/Delete
        if ("Admin".equalsIgnoreCase(userRole)) {
            holder.btnEdit.setVisibility(View.VISIBLE);
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.btnEdit.setOnClickListener(v -> listener.onEditClick(product));
            holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(product));
        } else {
            holder.btnEdit.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
        }
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvName, tvPrice, tvStock, tvCategory;
        private final ImageView ivProduct;
        private final ImageButton btnEdit, btnDelete;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvProductName);
            tvPrice = itemView.findViewById(R.id.tvProductPrice);
            tvStock = itemView.findViewById(R.id.tvProductStock);
            tvCategory = itemView.findViewById(R.id.tvProductCategory);
            ivProduct = itemView.findViewById(R.id.ivProductImage);
            btnEdit = itemView.findViewById(R.id.btnEditProduct);
            btnDelete = itemView.findViewById(R.id.btnDeleteProduct);
        }
    }
}
