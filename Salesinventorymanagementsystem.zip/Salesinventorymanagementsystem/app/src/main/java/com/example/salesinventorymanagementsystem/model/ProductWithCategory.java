package com.example.salesinventorymanagementsystem.model;

import androidx.room.Embedded;
import androidx.room.Relation;

public class ProductWithCategory {
    @Embedded
    public Product product;

    @Relation(
            parentColumn = "categoryId",
            entityColumn = "id"
    )
    public Category category;
}
